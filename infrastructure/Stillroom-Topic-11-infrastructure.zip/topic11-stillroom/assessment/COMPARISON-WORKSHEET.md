# Burp Suite and ZAP comparison worksheet

Use one copy for your captured tool observations. Record the specific exchange or alert that supports each observation. Keep the [synthetic exercises](EXERCISES.md) separate from this worksheet.

| Run detail | Burp Suite | ZAP |
| --- | --- | --- |
| Session name and date | | |
| Tool edition and version | | |
| Browser and version | | |
| Seed reset and accounts used | | |
| Tool settings and proxy listener | | |
| Time measured from / to | | |

| Case | Tool | Method, route, and identity | What the tool showed | Evidence reference and quality | Manual, source, or test review needed | Time spent verifying |
| --- | --- | --- | --- | --- | --- | --- |
| C1 · Catalogue query | Burp | | | | | |
| C1 · Catalogue query | ZAP | | | | | |
| C2 · Search reflection | Burp | | | | | |
| C2 · Search reflection | ZAP | | | | | |
| C3 · Order and receipt ownership | Burp | | | | | |
| C3 · Order and receipt ownership | ZAP | | | | | |
| C4 · Fulfilment rules | Burp | | | | | |
| C4 · Fulfilment rules | ZAP | | | | | |

Use additional rows for distinct resources or roles. In the evidence column, note what the screenshot, transaction, or alert shows and whether it supports the proposed conclusion. Start each verification timer when you open the relevant evidence. Stop when you have enough evidence to record a conclusion or identify the remaining check.
