# Reviewer key

Read the [synthetic observations](EXERCISES.md) first. This key gives the answers for those examples and points to regression evidence from the delivered Stillroom app. An empty passive alert list records what the tool reported. Establish whether each control works with the response, source, or tests below.

## C1 · Catalogue search and SQL injection

**Synthetic verdict.** The `500` establishes that the request failed. The status and generic error text leave the query-structure claim unsubstantiated. Evidence that input reached the SQL statement as syntax, or changed the structure that SQLite parsed, would support the claim. Query traces can distinguish statement text, bound values, and the failure that occurred.

**Verified control.** In `searchCatalogue`, the statement uses placeholders for the search pattern, category, page limit, and offset. Sort clauses come from the fixed `sorts` map. The regression test records statement text and parameters separately. It checks that changing `Roaster's` to `Daybreak` leaves both statements identical, that apostrophes work, that literal LIKE metacharacters stay literal, and that an unsupported sort selects the default expression. The HTTP test confirms filtering and pagination on the seeded catalogue. An ordinary `Roaster's` search returns **Roaster’s Reserve**. [Query source](../src/catalogue.mjs), [tests](../test/shop.test.mjs)

Proxy evidence can show what was sent and received. Use source or test evidence for the binding and sort allowlist claims.

```sh
node --test --test-name-pattern='catalogue SQL|guests can search' test/shop.test.mjs
```

## C2 · Reflected text in search results

**Synthetic verdict.** This is a false positive for reflected XSS in the two shown contexts. The value appears as HTML text inside the span and as data inside a quoted attribute. In the response, `&lt;` and `&gt;` encode the brackets, `&amp;` encodes the ampersand, and `&quot;` keeps the text’s quote characters inside the attribute value. The browser displays the original characters as text. Its DOM contains a text node in the heading and a single field value.

**Verified control.** `escapeHtml` encodes both outlets in the catalogue view. The HTTP regression asserts the exact encoded value in both contexts. A direct browser check also verified that the displayed heading and field contain the literal text and that the sample string creates no element. For your own evidence, capture the raw response and inspect the matching heading and input in the browser. [View source](../src/views.mjs), [test](../test/shop.test.mjs)

```sh
node --test --test-name-pattern='search reflection' test/shop.test.mjs
```

## C3 · Order and receipt ownership

**Synthetic verdict.** The owner’s responses establish that order and receipt identifiers are visible to an authorized user. The recorded peer responses show no cross-customer disclosure. A response to Jamie that disclosed Alex’s order or supplied Alex’s receipt would support the finding. The request identity and returned data must both be clear in the evidence.

**Verified control.** The server resolves the role from the session and checks each resource. `visibleOrder` matches the authenticated customer ID for customer reads. `ownedReceipt` matches the receipt ID and customer ID independently of the order page. The schema also constrains which customer and order each receipt can reference. [Route handlers](../src/http.mjs), [ownership queries](../src/records.mjs), [schema](../src/schema.sql)

| Identity | Order details | Receipt |
| --- | --- | --- |
| Guest | `303` to sign-in | `303` to sign-in |
| Owner | `200`, owned order | `200`, owned attachment |
| Other customer | Generic `404` | Generic `404`, no attachment |
| Staff | `200`, fulfilment details | `403` |

Use the source and both regression tests to verify the role matrix. A single response only covers the role and resource that produced it. The tests check that cross-customer error bodies match unknown-resource error bodies. [Tests](../test/shop.test.mjs)

```sh
node --test --test-name-pattern='order detail requires|receipts authorize' test/shop.test.mjs
```

## C4 · Fulfilment permissions and status transitions

**Synthetic verdict.** The customer’s `403` and unchanged state support the permission check. Staff are allowed to advance fulfilment, but the fictional persisted **Placed → Delivered** change skips two required stages. The fresh read and persisted history support the finding in that fictional build. A label or redirect alone supplies less evidence than a state read and event history.

**Verified control.** The route permits only the staff role. In the permission regression, the customer and staff attempt the same valid **Placed → Processing** transition. The customer receives `403` and the staff action advances the order. In the transition regression, the actor stays staff while the requested step varies. Skipped, backward, repeated, and terminal updates receive `409`. Valid steps produce the four-event sequence, visible to the owner on the order detail page. [Role gate](../src/http.mjs), [state rule and transaction](../src/records.mjs), [tests](../test/shop.test.mjs)

Use source or regression evidence to establish both rules. A capture of the normal staff workflow shows only the transition taken in that session.

```sh
node --test --test-name-pattern='only staff may|staff fulfilment' test/shop.test.mjs
```
