# Offline evidence exercises

**All observations on this sheet are synthetic.** They were written for practice and are separate from the exchanges you capture in Burp and ZAP. Evaluate each proposed finding before opening the [reviewer key](REVIEWER-KEY.md).

## C1 · Catalogue search and SQL injection

**Synthetic observation.** A reviewer tries the ordinary search text `Roaster's` with the Coffee filter. Their notes show a `500` on that search and a `200` on the unfiltered catalogue. The only error text they recorded is “Something went wrong.” There is no accompanying query trace.

**Proposed finding.** “An apostrophe caused a server error, so the input changed the SQL query.”

1. What can you conclude from the HTTP status and error text?
2. What source or test evidence would distinguish an application failure from input changing the structure of the statement?
3. What would you inspect for filtering, sorting, and pagination as well as the search value?

## C2 · Reflected text in search results

**Synthetic observation.** A user searches for the harmless text `Morning <sample> & "notes"`. The saved response has these excerpts.

```html
<span class="search-term">Morning &lt;sample&gt; &amp; &quot;notes&quot;</span>
<input name="q" value="Morning &lt;sample&gt; &amp; &quot;notes&quot;">
```

The browser shows the original characters in the result heading and search box. The element inspector shows a text node inside the span.

**Proposed finding.** “The search text appears in the HTML response, so the page has reflected XSS.”

1. Is the value reflected? Identify both contexts.
2. Does the evidence show the browser interpreting any part of the search text as markup or as a separate attribute?
3. Which details of the raw response and rendered page support your conclusion?

## C3 · Order and receipt ownership

**Synthetic observations.**

| Identity | Resource viewed | Observation |
| --- | --- | --- |
| Alex | Order SR-2101 | `200` with Alex’s delivery details and the linked receipt ID |
| Alex | Receipt R-6101 | `200` with an HTML attachment for SR-2101 |
| Jamie | Order SR-2101 | `404` with a generic error page |
| Jamie | Receipt R-6101 | `404` with a generic error page and no attachment |

**Proposed finding.** “An order number and a receipt number are visible, so another customer can access both records.”

1. What does the visibility of each identifier establish?
2. What response would actually support a claim of cross-customer disclosure?
3. What additional role checks or source evidence would you want for each resource?

## C4 · Fulfilment permissions and status transitions

**Synthetic observations from a fictional build.**

- A signed-in customer tries to use the staff action and receives `403`. The authoritative status remains **Placed**.
- A staff member selects the normal **Start processing** button on an order whose timeline begins with **Placed**. After the redirect, a fresh read shows **Delivered**. The persisted event history contains **Placed** followed directly by **Delivered**.

**Proposed finding.** “The fulfilment workflow allows an invalid status transition.”

1. Which observation concerns the actor’s permission? Which concerns the sequence?
2. Which evidence would distinguish a display bug from a persisted transition?
3. How could a permission test and a transition test each hold the other condition constant?
