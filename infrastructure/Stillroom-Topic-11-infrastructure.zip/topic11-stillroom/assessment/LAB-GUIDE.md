# Local lab guide

Use **http://127.0.0.1:8770/** and the accounts in the [startup guide](../README.md). The route matrix describes the intended role policy. Use the [offline exercises](EXERCISES.md) to practise interpreting evidence and the [worksheet](COMPARISON-WORKSHEET.md) for your own tool observations.

## Route and role matrix

| Method and route | Guest | Customer | Staff |
| --- | --- | --- | --- |
| `GET /` | Browse, search, filter, sort, paginate | Same catalogue | Same catalogue |
| `GET /products/:slug` | View details | View details and add in-stock items | View details |
| `GET /assets/:file` | Allowlisted CSS and images | Same | Same |
| `GET /login`, `POST /login` | View form and sign in | Redirect to catalogue | Redirect to fulfilment |
| `POST /logout` | Sign in first | End session | End session |
| `GET /cart`, `POST /cart/items` | Sign in first | View own cart and add products | Access denied |
| `POST /cart/items/:id/update`, `POST /cart/items/:id/remove` | Sign in first | Update or remove own cart items | Access denied |
| `GET /checkout`, `POST /checkout` | Sign in first | Confirm delivery and place a mock order from own cart | Access denied |
| `GET /orders` | Sign in first | View own order history | Access denied |
| `GET /orders/:id` | Sign in first | View an owned order | View any order |
| `GET /receipts/:id` | Sign in first | Download an owned receipt | Access denied |
| `GET /staff/orders` | Sign in first | Access denied | View and filter all orders |
| `POST /staff/orders/:id/status` | Sign in first | Access denied | Submit the next valid status |

The sign-in redirect is HTTP 303. Access denied is HTTP 403. A customer gets the same HTTP 404 page for an unowned order or receipt and an unknown identifier. All form submissions require the shop’s exact origin. Orders use numbers such as **SR-2101** and receipts have their own numbers such as **R-6101**.

## Prepare each tool session

1. Reset and restart the shop before each full walkthrough. Open a fresh browser profile and proxy session. Record the browser and tool versions.
2. In Burp Suite Community, start a temporary project. Under **Proxy → Intercept**, turn interception off and choose **Open browser**. Use **Proxy → HTTP history** to select a transaction and inspect its response. [Burp HTTP history](https://portswigger.net/burp/documentation/desktop/tools/proxy/http-history)
3. In ZAP, choose **Safe Mode**, then **Quick Start → Manual Explore**. Launch the browser at the shop URL with the HUD unchecked. Use **History**, **Response**, and **Alerts** to inspect the captured traffic. Wait for the passive queue to empty before recording the alert list. [ZAP modes](https://www.zaproxy.org/docs/desktop/start/features/modes/), [Manual Explore](https://www.zaproxy.org/docs/desktop/addons/quick-start/)
4. Confirm that `GET /` on `127.0.0.1:8770` appears in the proxy history. Run one proxy at a time if they share a listener port.

If the tool’s browser is unavailable, open a fresh Brave profile through its listener. This example uses port 8080. Use the actual listener port for your session.

```sh
brave --user-data-dir="$(mktemp -d /tmp/stillroom-proxy.XXXXXX)" \
  --no-first-run --proxy-server=http://127.0.0.1:8080 \
  --proxy-bypass-list='<-loopback>' http://127.0.0.1:8770/
```

## Repeat this browser journey

1. Start as a guest. Open the catalogue, select **Browse the collection**, and go to the next page. Select **Coffee** and sort **Price, low to high**. Use **Apply**. Search for `Roaster's`.
2. Sign in as Alex. Open **Roaster’s Reserve** and add it to the cart. Change the quantity to two and select **Update**. Open checkout.
3. Keep the prefilled delivery address, select **Approve test payment**, and place the order. Record the order number shown on screen. Use **Download receipt**, then sign out.
4. Sign in as Sam. Find the same order in **Fulfilment**, open it, and select **Start processing**. Sign out.
5. Sign back in as Alex. Open **My orders**, select the same order, and note its current status. Sign out. For a separate customer walkthrough, sign in as Jamie and open **My orders**.

For validation examples, search for a term that has no matches, open the empty cart, or choose **Decline test payment** during checkout. To compare the same successful journey again, restore the seed data first.

## Short recording shot list

| Clip | Capture |
| --- | --- |
| Burp ordinary workflow | Show the local URL, then browse, sign in, and place the mock order. End on the selected request and response in HTTP history. |
| ZAP ordinary workflow | Repeat the same browser sequence. End on the matching exchange in History and show the Alerts pane after the queue drains. |
| Finding triage | Open one [synthetic exercise](EXERCISES.md). Keep the synthetic label visible. State the initial claim, show the observation, and explain what extra evidence would change your conclusion. |
| Source or regression verification | Open the relevant source section or run one focused test from the [test suite](../test/shop.test.mjs). Show the control it exercises and the specific assertion you used to reach your conclusion. |

For each screenshot, include the method, route, and response evidence in the same frame when possible. For an ownership check, record which fixture role made the request. Keep synthetic exercise material in a separate folder from your captured tool evidence.
