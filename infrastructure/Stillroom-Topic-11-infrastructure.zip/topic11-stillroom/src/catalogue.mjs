export const categories = new Map([
  ['coffee', 'Coffee'],
  ['brewing', 'Brewing gear'],
  ['serveware', 'Serveware'],
]);

const sorts = new Map([
  ['featured', { label: 'Featured', clause: 'p.id ASC' }],
  ['price-asc', { label: 'Price, low to high', clause: 'p.price_cents ASC, p.id ASC' }],
  ['price-desc', { label: 'Price, high to low', clause: 'p.price_cents DESC, p.id ASC' }],
  ['name', { label: 'Name, A to Z', clause: 'p.name COLLATE NOCASE ASC, p.id ASC' }],
]);

export const sortChoices = [...sorts].map(([value, { label }]) => [value, label]);
export const searchLimit = 100;
const pageSize = 6;

export function searchCatalogue(db, params) {
  const q = (params.get('q') ?? '').trim();
  const category = categories.has(params.get('category')) ? params.get('category') : '';
  const sort = sorts.has(params.get('sort')) ? params.get('sort') : 'featured';

  if (q.length > searchLimit) {
    return {
      q: q.slice(0, searchLimit), category, sort, page: 1, pages: 1, total: 0, products: [],
      error: 'Use 100 characters or fewer to search the catalogue.',
    };
  }

  const conditions = [];
  const values = [];
  if (q) {
    // Treat the characters that have meaning in LIKE as literal search text.
    const pattern = '%' + q.replace(/[!%_]/g, '!$&') + '%';
    conditions.push("(p.name LIKE ? ESCAPE '!' OR p.description LIKE ? ESCAPE '!')");
    values.push(pattern, pattern);
  }
  if (category) {
    conditions.push('p.category = ?');
    values.push(category);
  }

  const where = conditions.length ? ' WHERE ' + conditions.join(' AND ') : '';
  const total = db.prepare('SELECT count(*) AS count FROM products p' + where).get(...values).count;
  const pages = Math.max(1, Math.ceil(total / pageSize));
  const requested = params.get('page') ?? '';
  const page = /^\d{1,6}$/.test(requested) ? Math.max(1, Math.min(Number(requested), pages)) : 1;

  // Only a complete, predefined ORDER BY expression can enter the statement.
  const products = db.prepare(
    'SELECT p.* FROM products p' + where + ' ORDER BY ' + sorts.get(sort).clause + ' LIMIT ? OFFSET ?',
  ).all(...values, pageSize, (page - 1) * pageSize);

  return { q, category, sort, page, pages, total, products };
}

export function productBySlug(db, slug) {
  return db.prepare('SELECT * FROM products WHERE slug = ?').get(slug);
}
