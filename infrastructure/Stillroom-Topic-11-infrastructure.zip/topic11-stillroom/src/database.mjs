import { mkdirSync, readFileSync } from 'node:fs';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { DatabaseSync } from 'node:sqlite';
import { seedRows } from './seed.mjs';

export const defaultDatabasePath = fileURLToPath(new URL('../data/stillroom.sqlite', import.meta.url));
const schema = readFileSync(new URL('./schema.sql', import.meta.url), 'utf8');

export function transaction(db, work) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = work();
    db.exec('COMMIT');
    return result;
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
}

export function openDatabase(path = defaultDatabasePath) {
  if (path !== ':memory:') mkdirSync(dirname(path), { recursive: true, mode: 0o700 });
  const db = new DatabaseSync(path);
  try {
    db.exec('PRAGMA busy_timeout = 5000; PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL');
    db.exec(schema);
    transaction(db, () => {
      if (!db.prepare('SELECT 1 FROM users LIMIT 1').get()) seedRows(db);
    });
    return db;
  } catch (error) {
    db.close();
    throw error;
  }
}

export function resetDatabase(db) {
  transaction(db, () => {
    db.exec('DELETE FROM sessions; DELETE FROM cart_items; DELETE FROM orders; DELETE FROM products; DELETE FROM users');
    seedRows(db);
  });
}
