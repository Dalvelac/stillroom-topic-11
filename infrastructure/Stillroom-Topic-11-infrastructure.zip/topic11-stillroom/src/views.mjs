import { categories, searchLimit, sortChoices } from './catalogue.mjs';
import { nextStatus, orderSteps, statusLabels } from './records.mjs';

const currency = new Intl.NumberFormat('en-IE', { style: 'currency', currency: 'EUR' });
const calendarDate = new Intl.DateTimeFormat('en-GB', { dateStyle: 'medium', timeZone: 'UTC' });
const entities = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };

export function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (character) => entities[character]);
}

const e = escapeHtml;
const money = (cents) => currency.format(cents / 100);
const date = (iso) => `<time datetime="${e(iso)}">${calendarDate.format(new Date(iso))}</time>`;
const active = (context, section) => context.section === section ? ' aria-current="page"' : '';

function notice(message) {
  return message ? `<p class="notice" role="alert">${e(message)}</p>` : '';
}

function layout(context, title, content) {
  const { user, cartCount } = context;
  const links = !user
    ? `<a class="nav-button" href="/login"${active(context, 'login')}>Sign in</a>`
    : user.role === 'staff'
      ? `<a href="/staff/orders"${active(context, 'staff')}>Fulfilment</a>`
      : `<a href="/orders"${active(context, 'orders')}>My orders</a>
         <a class="nav-button" href="/cart"${active(context, 'cart')}>Cart <span>${cartCount}</span></a>`;
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${e(title)} | Stillroom</title>
  <link rel="icon" type="image/webp" href="/assets/kite.webp">
  <link rel="stylesheet" href="/assets/shop.css">
</head>
<body>
  <a class="skip" href="#main">Skip to content</a>
  <header class="site-header">
    <div class="shell header-inner">
      <a class="wordmark" href="/"><span class="mark" aria-hidden="true"></span>Stillroom</a>
      <nav class="site-nav" aria-label="Main navigation">
        <a href="/"${active(context, 'catalogue')}>Catalogue</a>
        ${links}
        ${user ? '<form action="/logout" method="post"><button class="nav-link">Sign out</button></form>' : ''}
      </nav>
    </div>
  </header>
  <main class="shell main" id="main" tabindex="-1">${content}</main>
  <footer class="site-footer"><div class="shell"><span class="footer-brand">Stillroom</span><span>Coffee &amp; brewing</span></div></footer>
</body>
</html>`;
}

function option(value, label, selected) {
  return `<option value="${e(value)}"${value === selected ? ' selected' : ''}>${e(label)}</option>`;
}

function imageFor(product, className = '') {
  return `<img class="${className}" src="/assets/${e(product.image)}" alt="${e(product.image_alt)}" width="512" height="512">`;
}

function productCard(product) {
  const href = '/products/' + e(product.slug);
  return `<article class="product">
    <a class="product-image" href="${href}" tabindex="-1" aria-hidden="true">${imageFor(product)}</a>
    <div class="product-copy">
      <p class="category">${e(categories.get(product.category))}</p>
      <h3><a href="${href}">${e(product.name)}</a></h3>
      <p class="description">${e(product.description)}</p>
      <div class="product-bottom"><strong>${money(product.price_cents)}</strong>
        ${product.stock === 0 ? '<span class="quiet">Out of stock</span>' : ''}
      </div>
    </div>
  </article>`;
}

function pageHref(result, page) {
  const params = new URLSearchParams();
  if (result.q) params.set('q', result.q);
  if (result.category) params.set('category', result.category);
  if (result.sort !== 'featured') params.set('sort', result.sort);
  params.set('page', String(page));
  return '/?' + e(params.toString()) + '#collection';
}

function pagination(result) {
  if (result.pages < 2) return '';
  const { page, pages } = result;
  return `<nav class="pagination" aria-label="Catalogue pages">
    ${page > 1 ? '<a href="' + pageHref(result, page - 1) + '">Previous</a>' : ''}
    <span>Page ${page} of ${pages}</span>
    ${page < pages ? '<a href="' + pageHref(result, page + 1) + '">Next</a>' : ''}
  </nav>`;
}

export function catalogue(context, result) {
  const landing = !result.q && !result.category && result.sort === 'featured' && result.page === 1;
  const header = landing ? `<section class="hero" aria-labelledby="hero-title">
    <div class="hero-copy">
      <h1 id="hero-title">The first pour</h1>
      <p>Whole beans, precise brewing gear, and good cups for your morning routine.</p>
      <a href="#collection" class="button button-bright">Browse the collection</a>
    </div>
    <div class="hero-media"><img src="/assets/morning.webp" alt="Blue ceramic dripper over a glass coffee carafe" width="627" height="627"></div>
  </section>` : '<h1 class="page-title">Catalogue</h1>';
  const heading = result.q ? `Results for <span class="search-term">${e(result.q)}</span>` : 'The collection';
  return layout({ ...context, section: 'catalogue' }, 'Catalogue', `
    ${header}
    <section class="collection" id="collection" aria-labelledby="collection-heading">
      <div class="section-heading">
        <h2 id="collection-heading">${heading}</h2>
        <p>${result.total} ${result.total === 1 ? 'product' : 'products'}</p>
      </div>
      <form class="filters" action="/#collection" method="get">
        <div class="filter-search">
          <label for="search">Search products</label>
          <input id="search" name="q" type="search" maxlength="${searchLimit}" value="${e(result.q)}" placeholder="Coffee, carafe, filters…">
        </div>
        <div><label for="category">Category</label><select id="category" name="category">
          ${option('', 'All categories', result.category)}
          ${[...categories].map(([value, label]) => option(value, label, result.category)).join('')}
        </select></div>
        <div><label for="sort">Sort by</label><select id="sort" name="sort">
          ${sortChoices.map(([value, label]) => option(value, label, result.sort)).join('')}
        </select></div>
        <button class="button">Apply</button>
      </form>
      ${notice(result.error)}
      ${result.products.length
        ? '<div class="product-grid">' + result.products.map(productCard).join('') + '</div>'
        : '<div class="empty"><h3>No products found</h3><p>Try another term or choose a different category.</p><a href="/#collection">Clear filters</a></div>'}
      ${pagination(result)}
    </section>`);
}

export function productDetail(context, product) {
  const controls = product.stock === 0
    ? '<p class="notice notice-neutral">This product is currently out of stock.</p>'
    : context.user?.role === 'customer' ? `<form class="buy" action="/cart/items" method="post">
        <input type="hidden" name="productId" value="${product.id}">
        <div><label for="buy-quantity">Quantity</label>
          <input id="buy-quantity" name="quantity" type="number" min="1" max="${Math.min(product.stock, 20)}" value="1" required></div>
        <button class="button">Add to cart</button>
      </form>`
      : !context.user ? '<a class="button" href="/login">Sign in to add to cart</a>' : '';
  return layout(context, product.name, `
    <a class="back" href="/#collection">Back to catalogue</a>
    <div class="product-detail">
      <div class="detail-image">${imageFor(product)}</div>
      <section class="detail-copy">
        <p class="category">${e(categories.get(product.category))}</p>
        <h1>${e(product.name)}</h1>
        <p class="lead">${e(product.description)}</p>
        <p class="detail-price">${money(product.price_cents)}</p>
        ${controls}
        <dl class="facts"><div><dt>Product code</dt><dd>${e(product.sku)}</dd></div>
          <div><dt>Availability</dt><dd>${product.stock ? 'In stock' : 'Out of stock'}</dd></div></dl>
      </section>
    </div>`);
}

export function login(context, { email = '', error = '' } = {}) {
  return layout({ ...context, section: 'login' }, 'Sign in', `
    <section class="signin">
      <div class="signin-copy">
        <h1>Sign in</h1>
        <p class="lead">View your orders or continue shopping.</p>
        ${notice(error)}
        <form class="field-stack" method="post" action="/login">
          <div><label for="email">Email address</label>
            <input id="email" name="email" type="email" autocomplete="username" maxlength="254" value="${e(email)}" required></div>
          <div><label for="password">Password</label>
            <input id="password" name="password" type="password" autocomplete="current-password" maxlength="128" required></div>
          <button class="button">Sign in</button>
        </form>
      </div>
      <div class="signin-media"><img src="/assets/morning.webp" alt="" width="627" height="627"></div>
    </section>`);
}

function cartItem(product) {
  return `<li class="cart-row">
    ${imageFor(product, 'thumb')}
    <div class="cart-product"><a href="/products/${e(product.slug)}">${e(product.name)}</a><span>${money(product.price_cents)} each</span>
      ${product.quantity > product.stock ? '<p class="stock-warning">Quantity exceeds available stock.</p>' : ''}
    </div>
    <div class="cart-actions">
      <form action="/cart/items/${product.id}/update" method="post">
        <label class="sr-only" for="quantity-${product.id}">Quantity for ${e(product.name)}</label>
        <input id="quantity-${product.id}" name="quantity" type="number" min="1" max="20" value="${product.quantity}" required>
        <button class="button button-outline button-small">Update</button>
      </form>
      <form action="/cart/items/${product.id}/remove" method="post"><button class="text-button" aria-label="Remove ${e(product.name)}">Remove</button></form>
    </div>
    <strong class="cart-line-total">${money(product.quantity * product.price_cents)}</strong>
  </li>`;
}

function totalLine(total) {
  return `<div class="total"><span>Total</span><strong>${money(total)}</strong></div>`;
}

export function cartPage(context, cart, error = '') {
  const content = cart.items.length ? `
    <div class="two-columns basket-layout">
      <ul class="cart-items panel">${cart.items.map(cartItem).join('')}</ul>
      <aside class="panel summary">
        <h2>Order summary</h2>
        <div class="summary-line"><span>Delivery</span><span>Included</span></div>
        ${totalLine(cart.total)}
        <a class="button" href="/checkout">Go to checkout</a>
      </aside>
    </div>` : `<section class="empty"><h2>Your cart is empty</h2><p>Find something for your next pour.</p><a class="button" href="/#collection">Browse products</a></section>`;
  return layout({ ...context, section: 'cart' }, 'Your cart', `
    <h1 class="page-title">Your cart</h1>${notice(error)}${content}`);
}

export function checkout(context, cart, details, { error = '', payment = 'approve' } = {}) {
  function field(name, label, value, autocomplete, max) {
    return `<div><label for="${name}">${label}</label>
      <input id="${name}" name="${name}" value="${e(value)}" autocomplete="${autocomplete}" maxlength="${max}" required></div>`;
  }
  return layout({ ...context, section: 'cart' }, 'Checkout', `
    <a class="back" href="/cart">Back to cart</a>
    <h1 class="page-title">Checkout</h1>
    ${notice(error)}
    <form action="/checkout" method="post" class="two-columns checkout-layout">
      <section class="panel field-stack" aria-labelledby="delivery-heading">
        <h2 id="delivery-heading">Delivery address</h2>
        ${field('recipient', 'Full name', details.recipient, 'name', 80)}
        ${field('street', 'Street address', details.street, 'street-address', 120)}
        <div class="address-fields">
          ${field('city', 'City', details.city, 'address-level2', 60)}
          ${field('postalCode', 'Postal code', details.postalCode, 'postal-code', 12)}
        </div>
        <p class="quiet">Delivery within Czechia</p>
        <fieldset class="payment">
          <legend>Simulated payment</legend>
          <label><input type="radio" name="payment" value="approve"${payment !== 'decline' ? ' checked' : ''}> Approve test payment</label>
          <label><input type="radio" name="payment" value="decline"${payment === 'decline' ? ' checked' : ''}> Decline test payment</label>
        </fieldset>
      </section>
      <aside class="panel summary">
        <h2>Order summary</h2>
        ${cart.items.map((item) => '<div class="summary-line"><span>' + item.quantity + ' × ' + e(item.name) + '</span><span>' + money(item.quantity * item.price_cents) + '</span></div>').join('')}
        <div class="summary-line"><span>Delivery</span><span>Included</span></div>
        ${totalLine(cart.total)}
        <button class="button">Place order</button>
      </aside>
    </form>`);
}

function statusBadge(status) {
  return `<span class="badge badge-${e(status)}">${e(statusLabels[status])}</span>`;
}

export function ordersPage(context, orders, { staff = false, filter = '' } = {}) {
  const title = staff ? 'Fulfilment' : 'My orders';
  const filterForm = staff ? `<form class="staff-filter" action="/staff/orders" method="get">
    <div><label for="status-filter">Status</label><select id="status-filter" name="status">
      ${option('', 'All statuses', filter)}
      ${orderSteps.map((key) => option(key, statusLabels[key], filter)).join('')}
    </select></div><button class="button">Filter orders</button>
  </form>` : '<p class="lead">Orders for ' + e(context.user.full_name) + '.</p>';
  const rows = orders.map((order) => `<tr>
    <th scope="row"><a href="/orders/${order.id}">SR-${order.id}</a></th>
    <td>${date(order.placed_at)}</td>
    ${staff ? '<td>' + e(order.full_name) + '</td>' : ''}
    <td>${statusBadge(order.status)}</td><td class="amount">${money(order.total_cents)}</td>
  </tr>`);
  const table = orders.length ? `<div class="panel table-wrap"><table>
    <thead><tr><th scope="col">Order</th><th scope="col">Date</th>${staff ? '<th scope="col">Customer</th>' : ''}
      <th scope="col">Status</th><th scope="col" class="amount">Total</th></tr></thead>
    <tbody>${rows.join('')}</tbody>
  </table></div>` : '<div class="empty"><h2>No orders to show</h2>' + (staff ? '<a href="/staff/orders">View all orders</a>' : '<a class="button" href="/">Browse the catalogue</a>') + '</div>';
  return layout({ ...context, section: staff ? 'staff' : 'orders' }, title, `
    <div class="page-heading"><h1>${title}</h1>${filterForm}</div>${table}`);
}

function lineItems(items) {
  return `<div class="table-wrap"><table class="line-items">
    <thead><tr><th scope="col">Product</th><th scope="col">Quantity</th><th scope="col" class="amount">Amount</th></tr></thead>
    <tbody>${items.map((item) => `<tr><th scope="row">${e(item.name)} <span class="item-sku">${e(item.sku)}</span></th>
       <td>${item.quantity}</td><td class="amount">${money(item.quantity * item.price_cents)}</td></tr>`).join('')}</tbody>
  </table></div>`;
}

function shippingAddress(order) {
  return `<address>${e(order.recipient)}<br>${e(order.street)}<br>${e(order.postal_code)} ${e(order.city)}<br>Czechia</address>`;
}

export function orderPage(context, order, error = '') {
  const staff = context.user.role === 'staff';
  const next = nextStatus(order.status);
  const nextAction = { processing: 'Start processing', shipped: 'Mark as shipped', delivered: 'Mark as delivered' };
  let action = '';
  if (staff && next) {
    action = `<form method="post" action="/staff/orders/${order.id}/status">
      <input type="hidden" name="status" value="${next}">
      <button class="button">${nextAction[next]}</button>
    </form>`;
  } else if (!staff && order.receipt_id) {
    action = `<a class="button button-outline" href="/receipts/${order.receipt_id}">Download receipt</a>`;
  }
  return layout({ ...context, section: staff ? 'staff' : 'orders' }, 'Order SR-' + order.id, `
    <a class="back" href="${staff ? '/staff/orders' : '/orders'}">Back to ${staff ? 'fulfilment' : 'my orders'}</a>
    <div class="page-heading order-heading"><div><h1>Order SR-${order.id}</h1>
      <p class="lead">Placed ${date(order.placed_at)} ${statusBadge(order.status)}</p></div>${action}</div>
    ${notice(error)}
    <div class="two-columns order-layout">
      <section class="panel order-summary" aria-labelledby="order-summary-heading">
        <h2 id="order-summary-heading">Order summary</h2>
        ${lineItems(order.items)}${totalLine(order.total_cents)}
        <div class="order-address"><h3>Delivery address</h3>${shippingAddress(order)}${staff ? '<p>' + e(order.email) + '</p>' : ''}</div>
      </section>
      <section class="panel" aria-labelledby="timeline-heading">
        <h2 id="timeline-heading">Order history</h2>
        <ol class="timeline">${order.events.map((event) => `<li><strong>${e(statusLabels[event.status])}</strong>${date(event.occurred_at)}</li>`).join('')}</ol>
      </section>
    </div>`);
}

export function receiptPage(receipt) {
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Receipt R-${receipt.id} | Stillroom</title>
  <style>
    body { margin: 2rem auto; width: min(40rem, 92%); font: 16px/1.5 system-ui, sans-serif; color: #15233e; }
    header { border-bottom: 2px solid #15233e; margin-bottom: 1rem; } h1 { margin-bottom: .25rem; } address { font-style: normal; }
    table { width: 100%; border-collapse: collapse; margin-top: 1.5rem; } th, td { text-align: left; padding: .55rem; border-bottom: 1px solid #bcc8d8; }
    .amount, .total { text-align: right; } .total strong { margin-left: .75rem; } .item-sku { display: block; font-size: .85em; font-weight: normal; }
  </style>
</head>
<body>
  <header><p>Stillroom</p><h1>Receipt R-${receipt.id}</h1><p>Order SR-${receipt.order_id} · ${date(receipt.issued_at)}</p></header>
  <h2>Delivery address</h2>${shippingAddress(receipt)}
  ${lineItems(receipt.items)}
  ${totalLine(receipt.total_cents)}
  <p>Paid by simulated payment.</p>
</body>
</html>`;
}

export function messagePage(context, title, text, href = '/', linkText = 'Back to catalogue') {
  return layout(context, title, `<section class="panel message">
    <h1>${e(title)}</h1><p>${e(text)}</p><a class="button" href="${e(href)}">${e(linkText)}</a>
  </section>`);
}
