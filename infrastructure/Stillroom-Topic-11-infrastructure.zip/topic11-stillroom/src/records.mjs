import { createHash, randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';
import { transaction } from './database.mjs';

export class StoreError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

export const cookieName = 'stillroom_store';
const sessionSeconds = 1800;
const fallbackSalt = randomBytes(16).toString('hex');
const fallbackHash = Buffer.alloc(64);
const tokenHash = (token) => createHash('sha256').update(token).digest('hex');

export function checkCredentials(db, email, password) {
  const row = db.prepare('SELECT id, role, password_salt, password_hash FROM users WHERE email = ?').get(email);
  const candidate = scryptSync(password, row?.password_salt ?? fallbackSalt, 64);
  const expected = row ? Buffer.from(row.password_hash, 'hex') : fallbackHash;
  if (timingSafeEqual(candidate, expected) && row) return { id: row.id, role: row.role };
}

export function startSession(db, userId, replacedToken) {
  const token = randomBytes(32).toString('base64url');
  const now = Date.now();
  transaction(db, () => {
    db.prepare('DELETE FROM sessions WHERE expires_at <= ?').run(now);
    endSession(db, replacedToken);
    db.prepare('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)')
      .run(tokenHash(token), userId, now + sessionSeconds * 1000);
  });
  return makeCookie(token, sessionSeconds);
}

export function getUser(db, token) {
  if (!token) return undefined;
  return db.prepare(
    'SELECT u.id, u.email, u.full_name, u.role, u.street, u.city, u.postal_code ' +
    'FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ? AND s.expires_at > ?',
  ).get(tokenHash(token), Date.now());
}

export function endSession(db, token) {
  if (token) db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(tokenHash(token));
}

function makeCookie(value, age) {
  return cookieName + '=' + value + '; Path=/; HttpOnly; SameSite=Strict; Max-Age=' + age;
}

export const clearCookie = makeCookie('', 0);

export function getCart(db, customerId) {
  const items = db.prepare(
    'SELECT p.*, c.quantity FROM cart_items c JOIN products p ON p.id = c.product_id ' +
    'WHERE c.customer_id = ? ORDER BY p.name COLLATE NOCASE, p.id',
  ).all(customerId);
  const total = items.reduce((sum, row) => sum + row.price_cents * row.quantity, 0);
  return { items, total };
}

export function setCartQuantity(db, customerId, productId, quantity, operation) {
  if (!Number.isInteger(quantity) || quantity < 1 || quantity > 20) {
    throw new StoreError(422, 'Enter a quantity between 1 and 20.');
  }
  transaction(db, () => {
    const product = db.prepare('SELECT stock FROM products WHERE id = ?').get(productId);
    if (!product) throw new StoreError(404, 'This product could not be found.');

    const item = db.prepare('SELECT quantity FROM cart_items WHERE customer_id = ? AND product_id = ?')
      .get(customerId, productId);
    if (operation === 'replace' && !item) throw new StoreError(404, 'This item is no longer in your cart.');

    const desired = operation === 'add' ? quantity + (item?.quantity ?? 0) : quantity;
    if (desired > 20) throw new StoreError(422, 'Each product has a limit of 20 units per order.');
    if (desired > product.stock) throw new StoreError(409, 'There is not enough stock for that quantity.');

    db.prepare(
      'INSERT INTO cart_items (customer_id, product_id, quantity) VALUES (?, ?, ?) ' +
      'ON CONFLICT (customer_id, product_id) DO UPDATE SET quantity = excluded.quantity',
    ).run(customerId, productId, desired);
  });
}

export function removeCartItem(db, customerId, productId) {
  db.prepare('DELETE FROM cart_items WHERE customer_id = ? AND product_id = ?').run(customerId, productId);
}

export const orderSteps = ['placed', 'processing', 'shipped', 'delivered'];
export const statusLabels = {
  placed: 'Placed', processing: 'Processing', shipped: 'Shipped', delivered: 'Delivered',
};

export function nextStatus(status) {
  const position = orderSteps.indexOf(status);
  return position < 0 ? undefined : orderSteps[position + 1];
}

export function placeOrder(db, customerId, shipping, payment) {
  return transaction(db, () => {
    const cart = getCart(db, customerId);
    if (!cart.items.length) throw new StoreError(409, 'Your cart is empty.');
    if (payment === 'decline') {
      throw new StoreError(422, 'The simulated payment was declined. Your cart is ready for another try.');
    }

    const reserve = db.prepare('UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?');
    for (const item of cart.items) {
      if (reserve.run(item.quantity, item.id, item.quantity).changes !== 1) {
        throw new StoreError(409, 'Stock changed since you opened checkout. Review your cart and try again.');
      }
    }

    const placedAt = new Date().toISOString();
    const order = db.prepare(
      "INSERT INTO orders (customer_id, status, placed_at, recipient, street, city, postal_code, total_cents) " +
      "VALUES (?, 'placed', ?, ?, ?, ?, ?, ?)",
    ).run(customerId, placedAt, shipping.recipient, shipping.street, shipping.city, shipping.postalCode, cart.total);
    const orderId = Number(order.lastInsertRowid);
    const insertLine = db.prepare(
      'INSERT INTO order_items (order_id, product_id, sku, name, price_cents, quantity) VALUES (?, ?, ?, ?, ?, ?)',
    );
    for (const item of cart.items) {
      insertLine.run(orderId, item.id, item.sku, item.name, item.price_cents, item.quantity);
    }

    db.prepare('INSERT INTO receipts (order_id, customer_id, issued_at) VALUES (?, ?, ?)')
      .run(orderId, customerId, placedAt);
    db.prepare("INSERT INTO order_events (order_id, status, actor_id, occurred_at) VALUES (?, 'placed', ?, ?)")
      .run(orderId, customerId, placedAt);
    db.prepare('DELETE FROM cart_items WHERE customer_id = ?').run(customerId);
    return orderId;
  });
}

export function customerOrders(db, customerId) {
  return db.prepare('SELECT id, status, placed_at, total_cents FROM orders WHERE customer_id = ? ORDER BY id DESC')
    .all(customerId);
}

export function staffOrders(db, status) {
  const query = 'SELECT o.id, o.status, o.placed_at, o.total_cents, u.full_name FROM orders o ' +
    'JOIN users u ON u.id = o.customer_id';
  if (orderSteps.includes(status)) {
    return db.prepare(query + ' WHERE o.status = ? ORDER BY o.id DESC').all(status);
  }
  return db.prepare(query + ' ORDER BY o.id DESC').all();
}

const orderDetailsSql = 'SELECT o.*, u.email, r.id AS receipt_id FROM orders o ' +
  'JOIN users u ON u.id = o.customer_id ' +
  'LEFT JOIN receipts r ON r.order_id = o.id AND r.customer_id = o.customer_id WHERE o.id = ?';

function orderItems(db, orderId) {
  return db.prepare('SELECT sku, name, price_cents, quantity FROM order_items WHERE order_id = ? ORDER BY product_id')
    .all(orderId);
}

export function visibleOrder(db, user, orderId) {
  const order = user.role === 'staff'
    ? db.prepare(orderDetailsSql).get(orderId)
    : db.prepare(orderDetailsSql + ' AND o.customer_id = ?').get(orderId, user.id);
  if (!order) return undefined;
  const events = db.prepare('SELECT status, occurred_at FROM order_events WHERE order_id = ? ORDER BY id').all(orderId);
  return { ...order, items: orderItems(db, orderId), events };
}

export function ownedReceipt(db, customerId, receiptId) {
  const receipt = db.prepare(
    'SELECT r.id, r.order_id, r.issued_at, o.recipient, o.street, o.city, o.postal_code, o.total_cents ' +
    'FROM receipts r JOIN orders o ON o.id = r.order_id AND o.customer_id = r.customer_id ' +
    'WHERE r.id = ? AND r.customer_id = ?',
  ).get(receiptId, customerId);
  if (!receipt) return undefined;
  return { ...receipt, items: orderItems(db, receipt.order_id) };
}

export function changeOrderStatus(db, orderId, requested, staffId) {
  transaction(db, () => {
    const order = db.prepare('SELECT status FROM orders WHERE id = ?').get(orderId);
    if (!order) throw new StoreError(404, 'This order could not be found.');
    const next = nextStatus(order.status);
    if (!next || requested !== next) {
      throw new StoreError(409, 'That status change is unavailable. Reopen the order to see the next step.');
    }
    db.prepare('UPDATE orders SET status = ? WHERE id = ?').run(next, orderId);
    db.prepare('INSERT INTO order_events (order_id, status, actor_id, occurred_at) VALUES (?, ?, ?, ?)')
      .run(orderId, next, staffId, new Date().toISOString());
  });
}
