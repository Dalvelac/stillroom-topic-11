CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  full_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('customer', 'staff')),
  password_salt TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  street TEXT NOT NULL,
  city TEXT NOT NULL,
  postal_code TEXT NOT NULL
) STRICT;

CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at INTEGER NOT NULL
) STRICT;

CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  sku TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('coffee', 'brewing', 'serveware')),
  price_cents INTEGER NOT NULL CHECK (price_cents > 0),
  stock INTEGER NOT NULL CHECK (stock >= 0),
  image TEXT NOT NULL,
  image_alt TEXT NOT NULL
) STRICT;

CREATE TABLE IF NOT EXISTS cart_items (
  customer_id INTEGER NOT NULL REFERENCES users(id),
  product_id INTEGER NOT NULL REFERENCES products(id),
  quantity INTEGER NOT NULL CHECK (quantity BETWEEN 1 AND 20),
  PRIMARY KEY (customer_id, product_id)
) STRICT;

CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY,
  customer_id INTEGER NOT NULL REFERENCES users(id),
  status TEXT NOT NULL CHECK (status IN ('placed', 'processing', 'shipped', 'delivered')),
  placed_at TEXT NOT NULL,
  recipient TEXT NOT NULL,
  street TEXT NOT NULL,
  city TEXT NOT NULL,
  postal_code TEXT NOT NULL,
  total_cents INTEGER NOT NULL CHECK (total_cents > 0),
  UNIQUE (id, customer_id)
) STRICT;

CREATE INDEX IF NOT EXISTS orders_by_customer ON orders (customer_id, id DESC);

CREATE TABLE IF NOT EXISTS order_items (
  order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(id),
  sku TEXT NOT NULL,
  name TEXT NOT NULL,
  price_cents INTEGER NOT NULL CHECK (price_cents > 0),
  quantity INTEGER NOT NULL CHECK (quantity BETWEEN 1 AND 20),
  PRIMARY KEY (order_id, product_id)
) STRICT;

CREATE TABLE IF NOT EXISTS receipts (
  id INTEGER PRIMARY KEY,
  order_id INTEGER NOT NULL UNIQUE,
  customer_id INTEGER NOT NULL,
  issued_at TEXT NOT NULL,
  FOREIGN KEY (order_id, customer_id) REFERENCES orders (id, customer_id) ON DELETE CASCADE
) STRICT;

CREATE TABLE IF NOT EXISTS order_events (
  id INTEGER PRIMARY KEY,
  order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  status TEXT NOT NULL CHECK (status IN ('placed', 'processing', 'shipped', 'delivered')),
  actor_id INTEGER NOT NULL REFERENCES users(id),
  occurred_at TEXT NOT NULL,
  UNIQUE (order_id, status)
) STRICT;
