import { randomBytes, scryptSync } from 'node:crypto';

export const DEMO_ACCOUNTS = {
  alex: { email: 'alex.rowan@example.test', password: 'Stillroom-Alex-26' },
  jamie: { email: 'jamie.tan@example.test', password: 'Stillroom-Jamie-26' },
  staff: { email: 'sam.keller@example.test', password: 'Stillroom-Staff-26' },
};

const users = [
  [1, DEMO_ACCOUNTS.alex, 'Alex Rowan', 'customer', '14 Demo Lane', 'Ostrava', '700 30'],
  [2, DEMO_ACCOUNTS.jamie, 'Jamie Tan', 'customer', '8 Sample Court', 'Brno', '602 00'],
  [3, DEMO_ACCOUNTS.staff, 'Sam Keller', 'staff', '', '', ''],
];

const products = [
  [1, 'kite-dripper', 'SR-DR01', 'Kite Dripper', 'A ribbed cobalt ceramic dripper with an open base for an even pour.', 'brewing', 3400, 14, 'kite.webp', 'Cobalt ceramic pour-over dripper'],
  [2, 'field-carafe', 'SR-CA01', 'Field Carafe', 'A 400 ml heat-resistant glass carafe with an easy-pour handle.', 'serveware', 2800, 9, 'field.webp', 'Clear glass carafe with brewed coffee'],
  [3, 'daybreak-coffee', 'SR-CO01', 'Daybreak Coffee', 'A 250 g bag of whole beans with notes of orange peel and cocoa.', 'coffee', 1800, 18, 'daybreak.webp', 'Navy coffee pouch with a lime label'],
  [4, 'roasters-reserve', 'SR-CO02', "Roaster's Reserve", 'A 250 g small-batch coffee with apricot and brown sugar notes.', 'coffee', 2400, 8, 'reserve.webp', 'Navy coffee pouch with an orange label'],
  [5, 'paper-filters', 'SR-FI01', 'Paper Filters', 'A pack of 40 unbleached cone filters sized for the Kite Dripper.', 'brewing', 750, 24, 'filters.webp', 'Stack of pale cone-shaped paper filters'],
  [6, 'harbour-mug', 'SR-MU01', 'Harbour Mug', 'A low 220 ml stoneware mug with a hand-dipped cobalt glaze.', 'serveware', 2200, 11, 'harbour.webp', 'Low cobalt glazed mug'],
  [7, 'glass-tasting-cup', 'SR-CU01', 'Glass Tasting Cup', 'A clear 150 ml cup for tasting a small pour and seeing its colour.', 'serveware', 1600, 0, 'tasting.webp', 'Clear handled tasting cup'],
  [8, 'counter-scale', 'SR-SC01', 'Counter Scale', 'A slim digital scale with 0.1 g increments for repeatable pours.', 'brewing', 4200, 6, 'scale.webp', 'Rectangular charcoal kitchen scale'],
  [9, 'evening-decaf', 'SR-CO03', 'Evening Decaf', 'A 250 g decaf coffee with almond and milk chocolate notes.', 'coffee', 1750, 12, 'decaf.webp', 'Lilac coffee pouch with a cream label'],
];

const orders = [
  { id: 2101, owner: 1, date: '2026-11-08', states: ['placed', 'processing'], items: [[1, 1], [5, 2]] },
  { id: 2102, owner: 2, date: '2026-11-14', states: ['placed'], items: [[4, 1], [6, 1]] },
  { id: 2103, owner: 1, date: '2026-11-10', states: ['placed', 'processing', 'shipped'], items: [[3, 2]] },
  { id: 2104, owner: 2, date: '2026-11-02', states: ['placed', 'processing', 'shipped', 'delivered'], items: [[2, 1], [9, 1]] },
];

export function seedRows(db) {
  const insertUser = db.prepare(
    'INSERT INTO users (id, email, full_name, role, password_salt, password_hash, street, city, postal_code) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
  );
  for (const [id, account, name, role, street, city, postalCode] of users) {
    const salt = randomBytes(16).toString('hex');
    const hash = scryptSync(account.password, salt, 64).toString('hex');
    insertUser.run(id, account.email, name, role, salt, hash, street, city, postalCode);
  }

  const insertProduct = db.prepare(
    'INSERT INTO products (id, slug, sku, name, description, category, price_cents, stock, image, image_alt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
  );
  for (const product of products) insertProduct.run(...product);

  const insertOrder = db.prepare(
    'INSERT INTO orders (id, customer_id, status, placed_at, recipient, street, city, postal_code, total_cents) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
  );
  const insertLine = db.prepare(
    'INSERT INTO order_items (order_id, product_id, sku, name, price_cents, quantity) VALUES (?, ?, ?, ?, ?, ?)',
  );
  const insertReceipt = db.prepare('INSERT INTO receipts (id, order_id, customer_id, issued_at) VALUES (?, ?, ?, ?)');
  const insertEvent = db.prepare('INSERT INTO order_events (order_id, status, actor_id, occurred_at) VALUES (?, ?, ?, ?)');

  for (const { id, owner, date, states, items } of orders) {
    const [, , name, , street, city, postalCode] = users.find(([userId]) => userId === owner);
    const placedAt = date + 'T09:00:00.000Z';
    const lines = items.map(([productId, quantity]) => {
      const [, , sku, productName, , , price] = products.find(([rowId]) => rowId === productId);
      return { productId, quantity, sku, name: productName, price };
    });
    const total = lines.reduce((sum, line) => sum + line.price * line.quantity, 0);

    insertOrder.run(id, owner, states.at(-1), placedAt, name, street, city, postalCode, total);
    for (const line of lines) insertLine.run(id, line.productId, line.sku, line.name, line.price, line.quantity);
    insertReceipt.run(id + 4000, id, owner, placedAt);
    for (const [index, state] of states.entries()) {
      const occurredAt = new Date(Date.parse(placedAt) + index * 86_400_000).toISOString();
      insertEvent.run(id, state, index === 0 ? owner : 3, occurredAt);
    }
  }
}
