import { readFileSync } from 'node:fs';
import { createServer } from 'node:http';
import { productBySlug, searchCatalogue } from './catalogue.mjs';
import {
  changeOrderStatus, checkCredentials, clearCookie, cookieName, customerOrders, endSession, getCart,
  getUser, orderSteps, ownedReceipt, placeOrder, removeCartItem, setCartQuantity, staffOrders, startSession,
  StoreError, visibleOrder,
} from './records.mjs';
import * as views from './views.mjs';

export const host = '127.0.0.1';
export const labPort = 8770;

const policy = [
  "default-src 'none'", "style-src 'self'", "img-src 'self'", "base-uri 'none'",
  "form-action 'self'", "frame-ancestors 'none'", "frame-src 'none'",
].join('; ');

const defaultHeaders = {
  'Content-Type': 'text/html; charset=utf-8',
  'Content-Security-Policy': policy,
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'same-origin',
  'Cache-Control': 'private, no-store, no-cache, must-revalidate',
};

const assets = new Map(
  ['shop.css', 'morning.webp', 'kite.webp', 'field.webp', 'daybreak.webp', 'reserve.webp', 'filters.webp',
    'harbour.webp', 'tasting.webp', 'scale.webp', 'decaf.webp'].map((file) => [
    '/assets/' + file,
    {
      type: file.endsWith('.css') ? 'text/css; charset=utf-8' : 'image/webp',
      body: readFileSync(new URL('../public/' + file, import.meta.url)),
    },
  ]),
);

function send(res, status, body, headers = {}) {
  res.writeHead(status, { ...defaultHeaders, ...headers, 'Content-Length': Buffer.byteLength(body) });
  res.end(body);
}

function redirect(ctx, path, cookie) {
  const headers = { Location: path };
  if (cookie) headers['Set-Cookie'] = cookie;
  send(ctx.res, 303, '', headers);
}

function render(ctx, status, page, ...values) {
  const cartCount = ctx.user?.role === 'customer'
    ? ctx.db.prepare('SELECT COALESCE(SUM(quantity), 0) AS count FROM cart_items WHERE customer_id = ?')
      .get(ctx.user.id).count
    : 0;
  send(ctx.res, status, page({ user: ctx.user, cartCount }, ...values));
}

function notFound(ctx) {
  render(ctx, 404, views.messagePage, 'Page not found', 'This page could not be found.');
}

function denied(ctx) {
  render(ctx, 403, views.messagePage, 'Access denied', 'Your account does not have access to this page.');
}

const formLimit = 8192;
async function readForm(req) {
  const type = (req.headers['content-type'] ?? '').split(';')[0].trim().toLowerCase();
  if (type !== 'application/x-www-form-urlencoded') {
    throw new StoreError(415, 'Use the shop form to submit your changes.');
  }
  const chunks = [];
  let length = 0;
  for await (const chunk of req) {
    length += chunk.length;
    if (length <= formLimit) chunks.push(chunk);
  }
  if (length > formLimit) throw new StoreError(413, 'The form is too large. Review the fields and try again.');
  return new URLSearchParams(Buffer.concat(chunks).toString('utf8'));
}

function showCatalogue(ctx) {
  const result = searchCatalogue(ctx.db, ctx.url.searchParams);
  render(ctx, result.error ? 422 : 200, views.catalogue, result);
}

function showProduct(ctx, slug) {
  const product = productBySlug(ctx.db, slug);
  if (!product) return notFound(ctx);
  render(ctx, 200, views.productDetail, product);
}

const startPage = (user) => user.role === 'staff' ? '/staff/orders' : '/';

function showLogin(ctx) {
  if (ctx.user) return redirect(ctx, startPage(ctx.user));
  render(ctx, 200, views.login);
}

async function signIn(ctx) {
  if (ctx.user) return redirect(ctx, startPage(ctx.user));
  const form = await readForm(ctx.req);
  const email = (form.get('email') ?? '').trim().toLowerCase();
  const password = form.get('password') ?? '';
  if (email.length > 254 || !/^[^@\s]+@[^@\s]+$/.test(email) || !password || password.length > 128) {
    return render(ctx, 422, views.login, { email: email.slice(0, 254), error: 'Enter your email address and password.' });
  }

  const user = checkCredentials(ctx.db, email, password);
  if (!user) return render(ctx, 401, views.login, { email, error: 'Check your email and password and try again.' });
  redirect(ctx, startPage(user), startSession(ctx.db, user.id, ctx.token));
}

function signOut(ctx) {
  endSession(ctx.db, ctx.token);
  redirect(ctx, '/', clearCookie);
}

function showCart(ctx, error = '', status = 200) {
  render(ctx, status, views.cartPage, getCart(ctx.db, ctx.user.id), error);
}

const quantity = (form) => /^\d{1,2}$/.test(form.get('quantity') ?? '') ? Number(form.get('quantity')) : NaN;

function changeCart(ctx, productId, count, operation) {
  try {
    setCartQuantity(ctx.db, ctx.user.id, productId, count, operation);
  } catch (error) {
    if (error instanceof StoreError) return showCart(ctx, error.message, error.status);
    throw error;
  }
  redirect(ctx, '/cart');
}

async function addCartItem(ctx) {
  const form = await readForm(ctx.req);
  const productId = form.get('productId') ?? '';
  if (!/^\d{1,10}$/.test(productId)) return showCart(ctx, 'Choose a product from the catalogue.', 422);
  changeCart(ctx, Number(productId), quantity(form), 'add');
}

async function updateItem(ctx, productId) {
  const form = await readForm(ctx.req);
  changeCart(ctx, Number(productId), quantity(form), 'replace');
}

function removeItem(ctx, productId) {
  removeCartItem(ctx.db, ctx.user.id, Number(productId));
  redirect(ctx, '/cart');
}

function showCheckout(ctx) {
  const cart = getCart(ctx.db, ctx.user.id);
  if (!cart.items.length) return redirect(ctx, '/cart');
  const { full_name, street, city, postal_code } = ctx.user;
  render(ctx, 200, views.checkout, cart, { recipient: full_name, street, city, postalCode: postal_code });
}

const shippingFields = [
  ['recipient', 80], ['street', 120], ['city', 60], ['postalCode', 12],
];

async function submitOrder(ctx) {
  const form = await readForm(ctx.req);
  const details = Object.fromEntries(shippingFields.map(([key]) => [key, (form.get(key) ?? '').trim()]));
  const payment = form.get('payment');
  const cart = getCart(ctx.db, ctx.user.id);
  if (!cart.items.length) return showCart(ctx, 'Your cart is empty.', 409);

  if (shippingFields.some(([key, limit]) => !details[key] || details[key].length > limit || /[\r\n\x00]/.test(details[key]))) {
    return render(ctx, 422, views.checkout, cart, details, { payment, error: 'Enter a full delivery address within the field limits.' });
  }
  if (payment !== 'approve' && payment !== 'decline') {
    return render(ctx, 422, views.checkout, cart, details, { error: 'Choose a simulated payment outcome.' });
  }

  try {
    const orderId = placeOrder(ctx.db, ctx.user.id, details, payment);
    redirect(ctx, '/orders/' + orderId);
  } catch (error) {
    if (!(error instanceof StoreError)) throw error;
    const currentCart = getCart(ctx.db, ctx.user.id);
    if (!currentCart.items.length) return showCart(ctx, error.message, error.status);
    render(ctx, error.status, views.checkout, currentCart, details, { error: error.message, payment });
  }
}

function showOrders(ctx) {
  render(ctx, 200, views.ordersPage, customerOrders(ctx.db, ctx.user.id));
}

function showStaffOrders(ctx) {
  const requested = ctx.url.searchParams.get('status');
  const filter = orderSteps.includes(requested) ? requested : '';
  render(ctx, 200, views.ordersPage, staffOrders(ctx.db, filter), { staff: true, filter });
}

function showOrder(ctx, id) {
  const order = visibleOrder(ctx.db, ctx.user, Number(id));
  if (!order) return notFound(ctx);
  render(ctx, 200, views.orderPage, order);
}

function downloadReceipt(ctx, id) {
  const receipt = ownedReceipt(ctx.db, ctx.user.id, Number(id));
  if (!receipt) return notFound(ctx);
  send(ctx.res, 200, views.receiptPage(receipt), {
    'Content-Disposition': 'attachment; filename="stillroom-receipt-' + receipt.id + '.html"',
  });
}

async function updateStatus(ctx, id) {
  const form = await readForm(ctx.req);
  try {
    changeOrderStatus(ctx.db, Number(id), form.get('status'), ctx.user.id);
  } catch (error) {
    if (!(error instanceof StoreError)) throw error;
    if (error.status === 404) return notFound(ctx);
    const order = visibleOrder(ctx.db, ctx.user, Number(id));
    if (!order) return notFound(ctx);
    return render(ctx, error.status, views.orderPage, order, error.message);
  }
  redirect(ctx, '/orders/' + Number(id));
}

const routes = [
  ['GET', /^\/$/, 'public', showCatalogue],
  ['GET', /^\/products\/([a-z0-9-]+)$/, 'public', showProduct],
  ['GET', /^\/login$/, 'public', showLogin],
  ['POST', /^\/login$/, 'public', signIn],
  ['POST', /^\/logout$/, 'signed-in', signOut],
  ['GET', /^\/cart$/, 'customer', showCart],
  ['POST', /^\/cart\/items$/, 'customer', addCartItem],
  ['POST', /^\/cart\/items\/(\d{1,10})\/update$/, 'customer', updateItem],
  ['POST', /^\/cart\/items\/(\d{1,10})\/remove$/, 'customer', removeItem],
  ['GET', /^\/checkout$/, 'customer', showCheckout],
  ['POST', /^\/checkout$/, 'customer', submitOrder],
  ['GET', /^\/orders$/, 'customer', showOrders],
  ['GET', /^\/orders\/(\d{1,10})$/, 'signed-in', showOrder],
  ['GET', /^\/receipts\/(\d{1,10})$/, 'customer', downloadReceipt],
  ['GET', /^\/staff\/orders$/, 'staff', showStaffOrders],
  ['POST', /^\/staff\/orders\/(\d{1,10})\/status$/, 'staff', updateStatus],
];

const tokenPattern = new RegExp('(?:^|;\\s*)' + cookieName + '=([A-Za-z0-9_-]{43})(?=;|$)');

async function dispatch(ctx, origin) {
  const { req, res } = ctx;
  if (req.headers.host !== new URL(origin).host) {
    return send(res, 421, views.messagePage({}, 'Open Stillroom locally', 'Use ' + origin + ' to open the shop.'));
  }
  if (!req.url?.startsWith('/') || req.url.startsWith('//')) {
    return send(res, 400, views.messagePage({}, 'Invalid request', 'Open the catalogue and try again.'));
  }

  ctx.url = new URL(req.url, origin);
  const path = ctx.url.pathname;
  const method = req.method === 'HEAD' ? 'GET' : req.method;
  const asset = assets.get(path);
  if (asset && method === 'GET') {
    return send(res, 200, asset.body, { 'Content-Type': asset.type, 'Cache-Control': 'public, max-age=3600' });
  }

  ctx.token = (req.headers.cookie ?? '').match(tokenPattern)?.[1];
  ctx.user = getUser(ctx.db, ctx.token);

  const route = routes.find(([verb, pattern]) => verb === method && pattern.test(path));
  if (!route) {
    const methods = routes.filter(([, pattern]) => pattern.test(path)).map(([verb]) => verb);
    if (asset || methods.length) {
      if (asset) methods.push('GET');
      if (methods.includes('GET')) methods.push('HEAD');
      return send(res, 405, views.messagePage({ user: ctx.user, cartCount: 0 }, 'Method unavailable', 'Use the shop links or forms to continue.'), {
        Allow: methods.join(', '),
      });
    }
    return notFound(ctx);
  }

  const [, pattern, access, handler] = route;
  if (access !== 'public') {
    if (!ctx.user) return redirect(ctx, '/login');
    if (access !== 'signed-in' && ctx.user.role !== access) return denied(ctx);
  }
  if (method === 'POST' && req.headers.origin !== origin) {
    return render(ctx, 403, views.messagePage, 'Request declined', 'Return to the shop and submit the form again.');
  }
  await handler(ctx, ...pattern.exec(path).slice(1));
}

export function createShopServer(db) {
  const server = createServer({ headersTimeout: 5000, requestTimeout: 15000 }, (req, res) => {
    const ctx = { db, req, res };
    const origin = 'http://' + host + ':' + req.socket.localPort;
    dispatch(ctx, origin).catch((error) => {
      if (res.headersSent || res.destroyed) return;
      if (error instanceof StoreError) {
        return render(ctx, error.status, views.messagePage, 'Review your request', error.message);
      }
      console.error('Stillroom request failed:', error);
      send(res, 500, views.messagePage({ user: ctx.user, cartCount: 0 }, 'Something went wrong', 'Return to the shop and try again.'));
    });
  });
  return server;
}
