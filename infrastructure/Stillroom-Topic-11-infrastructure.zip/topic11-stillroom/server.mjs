import { openDatabase } from './src/database.mjs';
import { createShopServer, host, labPort } from './src/http.mjs';

const db = openDatabase();
const server = createShopServer(db);
server.once('close', () => db.close());
server.once('error', (error) => {
  console.error(error.code === 'EADDRINUSE' ? 'Port ' + labPort + ' is busy. Close the other listener first.' : error.message);
  db.close();
  process.exitCode = 1;
});
for (const signal of ['SIGINT', 'SIGTERM']) {
  process.once(signal, () => server.close());
}
server.listen(labPort, host, () => console.log('Stillroom listening at http://' + host + ':' + labPort + '/'));
