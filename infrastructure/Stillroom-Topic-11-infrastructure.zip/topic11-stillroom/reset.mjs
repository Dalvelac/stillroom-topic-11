import { defaultDatabasePath, openDatabase, resetDatabase } from './src/database.mjs';

const db = openDatabase();
try {
  resetDatabase(db);
  console.log('Restored the Stillroom seed data at ' + defaultDatabasePath);
} finally {
  db.close();
}
