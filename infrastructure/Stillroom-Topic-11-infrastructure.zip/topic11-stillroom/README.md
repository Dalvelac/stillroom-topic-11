# Stillroom

Stillroom is a local shop for the VŠB–TUO Topic 11 project, “Comparison of the Most Used Penetration Testing Tools and Systems.” It has nine products, customer carts and mock checkout, downloadable receipts, and a staff fulfilment queue.

## 1. Start the shop

Use Node.js 24 or later. From the folder containing `topic11-stillroom`, open a terminal and run the following commands. The app uses Node’s built-in SQLite module and has zero package dependencies. [Node.js SQLite documentation](https://nodejs.org/download/release/latest-v24.x/docs/api/sqlite.html)

```sh
cd topic11-stillroom
node --version
node server.mjs
```

Keep that terminal open. When it prints `Stillroom listening at http://127.0.0.1:8770/`, open [the catalogue](http://127.0.0.1:8770/). Use the exact address `http://127.0.0.1:8770/` throughout. The first start creates and seeds `data/stillroom.sqlite`. Orders, carts, and stock persist between starts.

### Stop and reset

Press **Ctrl+C** in the server terminal to stop the shop. Save your captures and worksheet entries before resetting. From `topic11-stillroom`, run the following commands to start a fresh pass.

```sh
node reset.mjs
node server.mjs
```

Reset restores the four seeded orders, stock, and empty carts, and clears sessions. Start a fresh browser profile or sign in again. If port 8770 is busy, open the catalogue to check for an existing Stillroom instance and use its server terminal to stop it before restarting.

## 2. Use the demo accounts

| Account | Email | Password | Access |
| --- | --- | --- | --- |
| Alex Rowan | `alex.rowan@example.test` | `Stillroom-Alex-26` | Customer |
| Jamie Tan | `jamie.tan@example.test` | `Stillroom-Jamie-26` | Customer |
| Sam Keller | `sam.keller@example.test` | `Stillroom-Staff-26` | Staff |

Guests can browse the catalogue without signing in. Each customer starts with two orders and an empty cart. Staff can view every order and move it from **Placed → Processing → Shipped → Delivered**. Customers download their own receipts as printable HTML files. Checkout uses a selectable simulated payment outcome.

See the [route and role matrix](assessment/LAB-GUIDE.md#route-and-role-matrix) for the intended access to each resource.

## 3. Set up one proxy per run

Reset the shop before each full walkthrough. Use a fresh proxy session and browser profile for each run. Record the tool edition, tool version, browser version, and listener in the [comparison worksheet](assessment/COMPARISON-WORKSHEET.md). If both tools use port 8080, close the first proxy before starting the second.

### Burp Suite Community

1. Start a **Temporary project in memory** with the default configuration.
2. Open **Proxy → Intercept**, set **Intercept off**, then choose **Open browser**.
3. In that browser, go to **http://127.0.0.1:8770/**. In **Proxy → HTTP history**, verify that `GET /` from that host appears.
4. Select a request in the history and open **Response → Raw** to see the status, headers, and body. Use the method and path to distinguish form submissions from the page loads that follow them. Save your screenshots and notes before closing the temporary project. [Burp HTTP history](https://portswigger.net/burp/documentation/desktop/tools/proxy/http-history)

### ZAP

1. Choose **File → New Session** and set **Safe Mode** in the toolbar.
2. Open **Quick Start → Manual Explore**, enter **http://127.0.0.1:8770/**, leave **Enable HUD** unchecked, and choose **Launch Browser**.
3. Verify that `GET /` appears in **History**. Select a request there and open **Response** to inspect it.
4. At the end of the walkthrough, wait for the passive queue to reach zero and capture the **Alerts** pane. Select a relevant alert to show its route and evidence when available. [ZAP modes](https://www.zaproxy.org/docs/desktop/start/features/modes/), [Manual Explore](https://www.zaproxy.org/docs/desktop/addons/quick-start/), [ZAP Desktop UI](https://www.zaproxy.org/docs/desktop/ui/)

### If the tool’s browser is unavailable

Check that the proxy listener is running on loopback. This Linux example launches Brave with a fresh profile through port 8080. Substitute the listener port displayed by your proxy.

```sh
brave --user-data-dir="$(mktemp -d /tmp/stillroom-proxy.XXXXXX)" \
  --no-first-run --proxy-server=http://127.0.0.1:8080 \
  --proxy-bypass-list='<-loopback>' http://127.0.0.1:8770/
```

If the shop loads but the proxy history is empty, check that you are using the proxy’s browser or the Brave window launched with those options. Verify the listener port and reload the catalogue before signing in.

## 4. Repeat this browser walkthrough

Follow the same order in Burp and ZAP. After a reset, the first new order is **SR-2105** and its receipt is **R-6105**. Write down the actual numbers shown during your run.

1. **Browse as a guest.** Select **Browse the collection**, then **Next** below the product grid. Set **Category** to **Coffee** and **Sort by** to **Price, low to high**, then select **Apply**. Enter `Roaster's` in **Search products** and select **Apply** again.
2. **Sign in as Alex.** Open **Sign in** in the header, enter Alex’s demo credentials, and submit. The customer flow returns to the catalogue.
3. **Update the cart.** Open **Roaster's Reserve** from the catalogue and choose **Add to cart**. Set its quantity to two and select **Update**. Use **Go to checkout**.
4. **Place the mock order.** Keep the prefilled delivery address. Select **Approve test payment** and choose **Place order**. Note the order number and current status on the order page.
5. **Download the receipt.** Select **Download receipt** on the order page. Open the downloaded HTML file to view its order number and total, then return to the shop and sign out.
6. **Advance fulfilment as Sam.** Sign in as Sam. Find the same order in **Fulfilment**, open it, and select **Start processing** once. Capture the new status and its timeline entry, then sign out.
7. **Check the customer view.** Sign in as Alex again. Open **My orders**, select the same order, and record the status there. Sign out. To show the second customer’s separate order history, sign in as Jamie and open **My orders**.

For a short validation example, use a search term with no matches or select **Decline test payment** during checkout. Capture the resulting message and response. Run the two main walkthroughs from a fresh seed before adding optional steps.

## 5. Screenshot checkpoints

Use names such as `burp-04-checkout-response.png` and `zap-04-checkout-response.png` to pair matching evidence. For proxy screenshots, keep the selected history row and the relevant response detail visible together. Include the local URL on at least one browser shot per run. When sharing captures, keep session cookie values and login form bodies out of frame.

| Checkpoint | Shop screenshot | Proxy screenshot |
| --- | --- | --- |
| 01 · Catalogue search | Show the search term, selected category and sort, and resulting product list. Capture page two if you want to show pagination. | Select the catalogue `GET /?…` with the matching query in the history. |
| 02 · Sign-in | Capture the sign-in form before entering credentials, or the catalogue immediately after signing in. | Select `POST /login` and show the `303` response and its `Location` header. |
| 03 · Cart | Show the product, quantity two, and total after **Update**. | Select `POST /cart/items/4/update` and the following `GET /cart`. |
| 04 · Checkout | Show the selected payment outcome and order summary before **Place order**. | Select `POST /checkout` and show the status and redirect to the new order. |
| 05 · Order and receipt | Show the order number and status. Optionally capture the opened receipt beside the order page. | Select `GET /receipts/6105` or the actual receipt path, with the status and `Content-Disposition` header. |
| 06 · Staff fulfilment | Capture the same order before and after **Start processing**, with the status and timeline visible. | Select `POST /staff/orders/2105/status` or the actual order path, then the order detail response that follows. |
| 07 · Customer follow-up | Show Alex’s copy of the same order with its updated status. An additional screenshot can show Jamie’s order list. | Select the order `GET /orders/2105` made during Alex’s session. Note which demo account produced each capture. |
| 08 · ZAP alerts | Use the same browser walkthrough for context. | Capture **Alerts** after the queue drains. For a relevant alert, keep its details and the matching exchange available. |

For the search-reflection exercise, a useful pair is the raw response and the rendered heading or input for the harmless term `Morning <sample> & "notes"`. Record what you observed in both views before opening the reviewer key.

## 6. Suggested short videos

Use the same start and end points for the two tool clips. If you shorten the walkthrough in editing, hold the selected request or result on screen long enough to read the route, status, and evidence.

| Clip | Suggested sequence |
| --- | --- |
| **Burp walkthrough** · 45–75 seconds | Start on the local catalogue. Show the search, cart or checkout, the order confirmation, and the customer-visible status update. End in **HTTP history** on `POST /checkout` and its response. |
| **ZAP walkthrough** · 45–75 seconds | Capture the same shop steps. End on the matching checkout exchange in **History → Response**, followed by **Alerts** once the queue reaches zero. |
| **Finding triage** · 30–45 seconds | Choose an observation from your own run or a [synthetic exercise](assessment/EXERCISES.md). Show the claim, the response or observation you used, and the evidence that supports or would change your conclusion. Keep the synthetic label visible when using the offline exercise. |
| **Source or test verification** · 30–45 seconds | Show the relevant source and one focused test. For example, open [the catalogue query](src/catalogue.mjs) at `searchCatalogue`, run the command below, then show the assertion you relied on and the test outcome. |

```sh
node --test --test-name-pattern='catalogue SQL' test/shop.test.mjs
```

For the worksheet, time from opening the relevant evidence to reaching a conclusion or identifying the next check you need. Record the evidence reference and whether manual inspection, source review, or a test was needed. An empty alert list describes what the tool reported. Use the matching response, source, or tests to assess the control.

## Assessment materials

- [Route and role matrix](assessment/LAB-GUIDE.md#route-and-role-matrix)
- [Four offline evidence exercises](assessment/EXERCISES.md)
- [Blank Burp and ZAP comparison worksheet](assessment/COMPARISON-WORKSHEET.md)
- [Separate reviewer key](assessment/REVIEWER-KEY.md) to open after recording your observations

## Source and checks

| File | Purpose |
| --- | --- |
| [server.mjs](server.mjs) and [HTTP handlers](src/http.mjs) | Local server, routes, and role checks |
| [Schema](src/schema.sql) and [seed data](src/seed.mjs) | SQLite tables, constraints, and fixture records |
| [Catalogue queries](src/catalogue.mjs) | Search, category filters, sort options, and pagination |
| [Store records](src/records.mjs) | Sessions, checkout transactions, ownership, and fulfilment |
| [Views](src/views.mjs) and [stylesheet](public/shop.css) | Shop pages and downloadable receipt template |
| [Regression tests](test/shop.test.mjs) | Direct checks against temporary loopback servers and SQLite databases |

```sh
npm run check
npm test
```

The tests use their own database files and ephemeral ports. The live lab can stay open while the tests run.

<details>
<summary>Product photography</summary>

The built-in image generation tool produced the product photography. The hero and first three product photos carry over from the Stillroom pilot. The six new photos use the six cells of one contact sheet. [Reserve](public/reserve.webp), [filters](public/filters.webp), [mug](public/harbour.webp), [tasting cup](public/tasting.webp), [scale](public/scale.webp), [decaf](public/decaf.webp)

> Make a photorealistic contact sheet of six product photographs for the Stillroom specialty coffee shop catalogue. Create exactly three equal columns by two equal rows, six square cells, no borders or gutters. Each cell will be cropped independently into its own photograph. Center one subject per cell with generous empty margin. Top row left to right: a small standing navy specialty coffee pouch with a plain burnt-orange panel and several coffee beans; a neat stack of pale cone-shaped paper coffee filters on a blue-grey studio surface; a low cobalt glazed ceramic coffee mug with a small handle. Bottom row left to right: a small transparent handled glass tasting cup with a little coffee inside; a slim rectangular charcoal precision kitchen scale with a simple blank digital display; an upright muted lilac coffee pouch with a plain cream label. Cool powder-blue and slate studio backdrops, soft daylight shadows, subtle tactile details, cohesive premium product photography. Objects fit wholly in their own cells. No readable text, branding, logos, marks or watermark. Landscape 3:2 composition.

</details>

## Optional infrastructure investigation

The legacy dispatch share represents a file drop the shop has retired. Baseline runs the real shop and a read-only FTP service. Hardened runs the same shop with FTP disabled. Both use the same lab host name, ports, sample and web state. The completed [recording and evidence](infra/recording/index.html) open offline.

### Start, switch, reset and stop

Download **Stillroom-Topic-11-infrastructure.zip** using **Download lab ZIP** on the presentation’s Infrastructure page. The archive contains the shop source, isolated launcher, sample file, recorded evidence and offline CVE exercise. Open a terminal in the folder containing the download and extract it into a new directory:

```sh
unzip Stillroom-Topic-11-infrastructure.zip -d stillroom-lab
cd stillroom-lab/topic11-stillroom
```

If you already extracted the archive, open a terminal in its `topic11-stillroom` directory. All file references below are relative to that directory unless the step specifies a different working directory. If an extractor discarded file permissions, restore the launcher with `chmod +x infra/lab`.

Use Linux with unprivileged user, network, mount and PID namespaces, Bash, util-linux (unshare, mount, flock), iproute2, curl, Node.js 24 or later, Python 3 with venv and pip, and ordinary shell utilities. First-time setup needs internet access for the pinned FTP package. The investigation runs locally. To collect new tool evidence, also install Nmap, Metasploit Framework with local PostgreSQL, and Wireshark with dumpcap and TShark. Verify these executables are available in the terminals you use. [pyftpdlib](https://github.com/giampaolo/pyftpdlib) · [Metasploit database support](https://docs.metasploit.com/docs/using-metasploit/intermediate/metasploit-database-support.html)

```sh
./infra/lab setup
./infra/lab baseline
```

On the original recording workstation, the evidence tools are installed under `$HOME/.cache/stillroom-topic11/bin`. If using that installation, prepend it to `PATH` in each host terminal. Its Metasploit wrapper manages the local database. Other Linux installations can use the tools already on their `PATH`.

The launcher opens a shell at `stillroom[baseline]$` inside a fresh namespace. Its only network link is `lo`. A private hosts file maps **stillroom.test** to **127.0.0.1**. Run the client steps in this shell. The normal shop starts through its existing `server.mjs`. A private mount maps the lab web database to `infra/.state/shop/`, separate from the everyday shop’s `data/`. You can run the everyday shop on the host at the same time. FTP binds to loopback inside the namespace. There is no bridge, published port or route to the LAN. Linux namespace support is required for this launcher.

Type `exit` to stop the services and leave the namespace. From the shop directory, use `./infra/lab hardened` for the retest or `./infra/lab baseline` to restore FTP. Each start recreates the FTP share from [dispatch.txt](infra/share/dispatch.txt) and restores its account. Changing modes keeps both SQLite databases and the evidence directory. Leave `reset.mjs` out of this investigation. To start a fresh evidence set, choose a new run directory and workspace name.

### 1. Nmap exposure check

In the **baseline lab shell**, start from its initial working directory, `infra/runs`. Choose one unused name and use it throughout. These examples use `my-run-01`. New evidence files are private by default.

```sh
mkdir -m 700 my-run-01 && cd my-run-01
ip -br address
getent ahostsv4 stillroom.test
nmap --unprivileged -sT -sV --version-light -Pn -n -p 21,8770 -oX baseline.xml stillroom.test
sha256sum baseline.xml
curl --disable --noproxy '*' -fsS http://127.0.0.1:8770/ -o catalogue-before.html
grep -o 'The first pour' catalogue-before.html
```

This is one host, two TCP ports and a light service identification pass. The scan describes ports reachable from this client at this time. Compare each XML `service` element’s `method` and `conf` attributes. A port-table guess can differ from what the application actually serves. The shop validates its HTTP Host header, so use the exact numeric URL for the catalogue. Nmap has no evidence that an account signed in. Keep this lab shell open for step 3. [Nmap XML output](https://nmap.org/book/output-formats-xml-output.html)

### 2. Metasploit inventory

Open a **second host terminal** in the shop directory. Start Metasploit from the directory that contains your XML. Start the local PostgreSQL database for your Framework installation and check its connection with `db_status` in the console.

```sh
cd infra/runs/my-run-01
sha256sum baseline.xml
msfconsole
```

At the Framework prompt, use a new baseline workspace for each run. Save the spool file in the current working directory.

```text
db_status
workspace -a topic11_my_run_01
spool inventory.txt
db_import baseline.xml
workspace
hosts -c address,name
services -c port,name,state,info
notes -a -t lab.exposure -n "Baseline XML reports FTP open on TCP 21." 127.0.0.1
notes -t lab.exposure
spool off
exit -y
```

Compare the address and service records with the original XML. The note is your annotation. A service name repeated by an importer is still one source of evidence. Use a separate workspace if you also import hardened XML so the baseline stays available.

### 3. Document the normal FTP retrieval

Return to the **baseline lab shell** in your run directory. The synthetic account is `dispatch`; its lab-default password is **`Stillroom-Demo-Only`**. It can list and retrieve the one file. The FTP account has no corresponding shop login. The following capture covers only this fixture’s control connection. The data connection uses a separate port.

```sh
dumpcap -i lo -f 'tcp port 21' -w control-private.pcapng >capture.log 2>&1 &
cap=$!
# Wait for capture.log to name the output file before continuing.
cat capture.log
curl --disable --noproxy '*' --fail --show-error --silent --user dispatch \
  --output dispatch.txt ftp://stillroom.test/dispatch.txt
# Type the documented password at curl's hidden prompt.
kill -INT "$cap"
wait "$cap"
cmp dispatch.txt ../../share/dispatch.txt && sha256sum dispatch.txt
```

Inspect the original privately. The command name `PASS` and server replies are visible on the control channel. The client used a known, supplied credential. The successful reply supports account acceptance, while the visibility of the exchange establishes the transport property. Changing password strength would still leave standard FTP without transport encryption. The matching file digest supplies separate evidence of the download.

For **screenshots, clips and the submission**, export just the allowlisted frames to a new capture. Open that file in the **host** Wireshark GUI. Password-bearing frames and the private capture stay out of the recording. Sequence-gap annotations can appear because frames were deliberately omitted. [Wireshark FTP field reference](https://www.wireshark.org/docs/dfref/f/ftp.html)

```sh
# Baseline lab shell, in the run directory
tshark -r control-private.pcapng \
  -Y 'ftp.request.command == "USER" || ftp.request.command == "RETR" || ftp.response.code in {220, 230, 331, 226}' \
  -w ftp-selected.pcapng
python3 -c "from pathlib import Path; assert b'Stillroom-Demo-Only' not in Path('ftp-selected.pcapng').read_bytes()"
```

```sh
# Second host terminal, in the same run directory
wireshark -n -r ftp-selected.pcapng
```

Show the welcome, USER, the 331 challenge, 230 acceptance, RETR filename and 226 completion. Keep the README credential, any private packet bytes and the password entry off-screen.

### 4. Retest the retired service

Type `exit` in the baseline lab shell. In its host terminal, from the shop directory, run `./infra/lab hardened`. In the new lab shell use the same run directory, target and Nmap options. Only the XML filename changes.

```sh
cd my-run-01
nmap --unprivileged -sT -sV --version-light -Pn -n -p 21,8770 -oX hardened.xml stillroom.test
curl --disable --noproxy '*' -fsS -o catalogue-after.html -w 'HTTP %{http_code}\n' http://127.0.0.1:8770/
grep -o 'The first pour' catalogue-after.html
python3 -c "import socket,errno; s=socket.socket(); rc=s.connect_ex(('127.0.0.1',21)); print(errno.errorcode.get(rc,rc)); assert rc==errno.ECONNREFUSED"
exit
```

### 5. Offline CVE evidence exercise

Open the [blank worksheet](infra/cve/WORKSHEET.md), [first inventory](infra/cve/inventory-before.json), [second inventory](infra/cve/inventory-after.json) and [offline Apache reference note](infra/cve/ADVISORY-NOTE.md). Compare the two files with `diff -u infra/cve/inventory-before.json infra/cve/inventory-after.json` from the shop directory. A difference yields exit status 1. Record the artifact, Java branch, affected interval and evidence missing for a runtime or incident conclusion. Check the [separate reviewer key](infra/cve/REVIEWER-KEY.md) after completing the worksheet. These JSON files are fictional inventory records. The shop loads no Log4j dependency. [Apache CVE-2021-44228 advisory](https://logging.apache.org/security.html#CVE-2021-44228)

| Evidence | Show on screen | Question to answer |
| --- | --- | --- |
| Nmap baseline XML | Host, both port states and service identification methods | Which service did Nmap identify from a probe? |
| Metasploit workspace and note | Active workspace, imported services and dated note | Which observations came from the XML, and what did you add? |
| FTP client and Wireshark | Redacted exchange plus matching download digest | What establishes a successful login, and what separately establishes plaintext transport? |
| Hardened XML and web check | Both port states beside HTTP status and catalogue title | Was FTP removed while the web workflow stayed available? |
| CVE inventories and worksheet | Matching core artifact in both builds beside Apache’s interval | Which dependency claim can you support, and what runtime evidence is missing? |
