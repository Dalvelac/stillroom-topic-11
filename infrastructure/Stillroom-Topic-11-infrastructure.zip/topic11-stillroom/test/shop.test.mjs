import assert from 'node:assert/strict';
import { once } from 'node:events';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import test from 'node:test';
import { searchCatalogue } from '../src/catalogue.mjs';
import { openDatabase, resetDatabase } from '../src/database.mjs';
import { createShopServer, host } from '../src/http.mjs';
import { DEMO_ACCOUNTS } from '../src/seed.mjs';

async function fixture(t) {
  const scratch = mkdtempSync(join(tmpdir(), 'stillroom-test-'));
  const db = openDatabase(join(scratch, 'fixture.sqlite'));
  const server = createShopServer(db);
  t.after(async () => {
    try {
      if (server.listening) await new Promise((resolve) => server.close(resolve));
      db.close();
    } finally {
      rmSync(scratch, { recursive: true, force: true });
    }
  });
  server.listen(0, host);
  await once(server, 'listening');
  const origin = 'http://' + host + ':' + server.address().port;

  function browser() {
    let cookie = '';
    async function request(path, { method = 'GET', fields = {}, headers = {} } = {}) {
      const options = { method, headers: {}, redirect: 'manual', signal: AbortSignal.timeout(5000) };
      if (cookie) options.headers.Cookie = cookie;
      if (method === 'POST') {
        options.headers.Origin = origin;
        options.body = new URLSearchParams(fields);
      }
      Object.assign(options.headers, headers);
      const response = await fetch(origin + path, options);
      const setCookie = response.headers.get('set-cookie');
      if (setCookie) cookie = setCookie.split(';', 1)[0];
      return { status: response.status, headers: response.headers, body: await response.text() };
    }
    return {
      get: (path) => request(path),
      post: (path, fields, headers) => request(path, { method: 'POST', fields, headers }),
      async login(fixtureName) {
        const response = await request('/login', { method: 'POST', fields: DEMO_ACCOUNTS[fixtureName] });
        assert.equal(response.status, 303);
        assert.match(response.headers.get('set-cookie'), /HttpOnly; SameSite=Strict/);
        return response;
      },
    };
  }
  return { db, browser };
}

function assertRedirect(response, path) {
  assert.equal(response.status, 303);
  assert.equal(response.headers.get('location'), path);
}

test('catalogue SQL binds literal search text and uses an allowlisted sort expression', (t) => {
  const db = openDatabase(':memory:');
  t.after(() => db.close());
  const calls = [];
  const capture = {
    prepare(sql) {
      const statement = db.prepare(sql);
      return {
        get(...args) {
          calls.push({ sql, args });
          return statement.get(...args);
        },
        all(...args) {
          calls.push({ sql, args });
          return statement.all(...args);
        },
      };
    },
  };

  const query = new URLSearchParams({ q: "Roaster's", category: 'coffee', sort: 'price-desc' });
  let result = searchCatalogue(capture, query);
  assert.deepEqual(result.products.map((row) => row.name), ["Roaster's Reserve"]);
  assert.equal(calls.length, 2);
  assert(calls.every((call) => call.sql.includes('p.name LIKE ?') && call.sql.includes('p.category = ?')));
  assert(calls.every((call) => !call.sql.includes("Roaster's")));
  assert.deepEqual(calls[0].args, ["%Roaster's%", "%Roaster's%", 'coffee']);
  assert.deepEqual(calls[1].args, ["%Roaster's%", "%Roaster's%", 'coffee', 6, 0]);
  assert.match(calls[1].sql, /ORDER BY p\.price_cents DESC, p\.id ASC LIMIT \? OFFSET \?/);

  const originalStatements = calls.splice(0).map((call) => call.sql);
  query.set('q', 'Daybreak');
  searchCatalogue(capture, query);
  assert.deepEqual(calls.map((call) => call.sql), originalStatements);

  calls.length = 0;
  query.set('sort', 'custom ordering');
  result = searchCatalogue(capture, query);
  assert.equal(result.sort, 'featured');
  assert.match(calls[1].sql, /ORDER BY p\.id ASC LIMIT \? OFFSET \?/);
  assert(!calls[1].sql.includes('custom ordering'));

  for (const q of ['%', '_', '!']) {
    assert.equal(searchCatalogue(db, new URLSearchParams({ q })).total, 0);
  }
});

test('guests can search, filter, sort, and paginate the catalogue', async (t) => {
  const shop = await fixture(t);
  const guest = shop.browser();
  const start = await guest.get('/');
  assert.equal(start.status, 200);
  assert.match(start.body, /9 products/);
  assert.match(start.body, /Page 1 of 2/);
  assert.equal((start.body.match(/class="product"/g) ?? []).length, 6);
  assert.match(start.body, /href="\/\?page=2#collection">Next/);

  const next = await guest.get('/?page=2');
  assert.equal(next.status, 200);
  assert.match(next.body, /Page 2 of 2/);
  assert.equal((next.body.match(/class="product"/g) ?? []).length, 3);
  assert.match(next.body, /Glass Tasting Cup/);
  assert.doesNotMatch(next.body, /Kite Dripper/);

  const filtered = await guest.get('/?category=coffee&sort=price-asc');
  assert.equal(filtered.status, 200);
  assert.match(filtered.body, /3 products/);
  assert.match(filtered.body, /Evening Decaf[\s\S]*Daybreak Coffee[\s\S]*Roaster&#39;s Reserve/);
  assert.doesNotMatch(filtered.body, /Counter Scale/);

  const apostrophe = await guest.get('/?q=' + encodeURIComponent("Roaster's"));
  assert.equal(apostrophe.status, 200);
  assert.match(apostrophe.body, /1 product/);
  assert.match(apostrophe.body, /Roaster&#39;s Reserve/);

  const long = await guest.get('/?q=' + 'x'.repeat(101));
  assert.equal(long.status, 422);
  assert.match(long.body, /Use 100 characters or fewer/);
  assert.match((await guest.get('/products/glass-tasting-cup')).body, /currently out of stock/);
});

test('search reflection is encoded in HTML text and the quoted value attribute', async (t) => {
  const shop = await fixture(t);
  const input = 'Morning <sample> & "notes"';
  const page = await shop.browser().get('/?q=' + encodeURIComponent(input));
  assert.equal(page.status, 200);
  const safe = 'Morning &lt;sample&gt; &amp; &quot;notes&quot;';
  assert(page.body.includes('<span class="search-term">' + safe + '</span>'));
  assert(page.body.includes('value="' + safe + '"'));
  assert(!page.body.includes(input));
  assert.doesNotMatch(page.body, /<sample>/);
  assert.match(page.body, /No products found/);
});

test('order detail requires sign-in and ownership or staff access', async (t) => {
  const shop = await fixture(t);
  const guest = shop.browser();
  const alex = shop.browser();
  const jamie = shop.browser();
  const staff = shop.browser();

  assertRedirect(await guest.get('/orders/2101'), '/login');
  await alex.login('alex');
  await jamie.login('jamie');
  assertRedirect(await staff.login('staff'), '/staff/orders');

  const owned = await alex.get('/orders/2101');
  assert.equal(owned.status, 200);
  assert.match(owned.body, /14 Demo Lane/);
  assert.match(owned.body, /href="\/receipts\/6101"/);

  const unowned = await jamie.get('/orders/2101');
  const unknown = await jamie.get('/orders/9999');
  assert.equal(unowned.status, 404);
  assert.equal(unowned.body, unknown.body);
  assert.doesNotMatch(unowned.body, /Alex Rowan|14 Demo Lane|6101/);
  assert.match((await jamie.get('/orders/2102')).body, /8 Sample Court/);

  const staffView = await staff.get('/orders/2101');
  assert.equal(staffView.status, 200);
  assert.match(staffView.body, /14 Demo Lane/);
  assert.doesNotMatch(staffView.body, /Download receipt/);
  const aOrders = await alex.get('/orders');
  const jOrders = await jamie.get('/orders');
  assert.match(aOrders.body, /\/orders\/2101/);
  assert.doesNotMatch(aOrders.body, /\/orders\/2102/);
  assert.match(jOrders.body, /\/orders\/2102/);
  assert.doesNotMatch(jOrders.body, /\/orders\/2101/);
});

test('receipts authorize their own resource for guest, owner, peer, and staff', async (t) => {
  const shop = await fixture(t);
  const guest = shop.browser();
  const alex = shop.browser();
  const jamie = shop.browser();
  const staff = shop.browser();

  assertRedirect(await guest.get('/receipts/6101'), '/login');
  await alex.login('alex');
  await jamie.login('jamie');
  await staff.login('staff');

  const owned = await alex.get('/receipts/6101');
  assert.equal(owned.status, 200);
  assert.equal(owned.headers.get('content-disposition'), 'attachment; filename="stillroom-receipt-6101.html"');
  assert.match(owned.headers.get('cache-control'), /\bno-store\b/);
  assert.match(owned.body, /Receipt R-6101/);
  assert.match(owned.body, /Order SR-2101/);
  assert.match(owned.body, /14 Demo Lane/);

  const peer = await jamie.get('/receipts/6101');
  assert.equal(peer.status, 404);
  assert.equal(peer.headers.get('content-disposition'), null);
  assert.equal(peer.body, (await jamie.get('/receipts/9999')).body);
  assert.doesNotMatch(peer.body, /Alex Rowan|14 Demo Lane/);
  assert.match((await jamie.get('/receipts/6102')).body, /Order SR-2102/);

  const denied = await staff.get('/receipts/6101');
  assert.equal(denied.status, 403);
  assert.equal(denied.headers.get('content-disposition'), null);
  assert.doesNotMatch(denied.body, /14 Demo Lane/);

  assert.throws(() => shop.db.prepare('UPDATE receipts SET customer_id = ? WHERE id = ?').run(2, 6101), /FOREIGN KEY/);
});

test('only staff may submit an otherwise valid fulfilment transition', async (t) => {
  const shop = await fixture(t);
  const guest = shop.browser();
  const owner = shop.browser();
  const staff = shop.browser();
  const path = '/staff/orders/2102/status';
  const next = { status: 'processing' };
  assertRedirect(await guest.post(path, next), '/login');

  await owner.login('jamie');
  assert.equal((await owner.get('/staff/orders')).status, 403);
  const response = await owner.post(path, next);
  assert.equal(response.status, 403);
  assert.match(response.body, /Access denied/);

  assert.equal(shop.db.prepare('SELECT status FROM orders WHERE id = 2102').get().status, 'placed');
  await staff.login('staff');
  assertRedirect(await staff.post(path, next), '/orders/2102');
  assert.match((await owner.get('/orders/2102')).body, /badge-processing/);
});

test('staff fulfilment enforces sequence and rejects stale or terminal updates', async (t) => {
  const shop = await fixture(t);
  const staff = shop.browser();
  const owner = shop.browser();
  await staff.login('staff');
  await owner.login('jamie');
  const path = '/staff/orders/2102/status';

  const skipped = await staff.post(path, { status: 'shipped' });
  assert.equal(skipped.status, 409);
  assert.match(skipped.body, /badge-placed/);
  assert.match(skipped.body, /That status change is unavailable/);
  assert.equal(shop.db.prepare('SELECT count(*) AS count FROM order_events WHERE order_id = 2102').get().count, 1);

  assertRedirect(await staff.post(path, { status: 'processing' }), '/orders/2102');
  assert.equal((await staff.post(path, { status: 'processing' })).status, 409);
  assert.equal((await staff.post(path, { status: 'placed' })).status, 409);
  assertRedirect(await staff.post(path, { status: 'shipped' }), '/orders/2102');
  assertRedirect(await staff.post(path, { status: 'delivered' }), '/orders/2102');
  assert.equal((await staff.post(path, { status: 'delivered' })).status, 409);
  assert.match((await owner.get('/orders/2102')).body, /badge-delivered/);
  assert.deepEqual(
    shop.db.prepare('SELECT status FROM order_events WHERE order_id = 2102 ORDER BY id').all().map((row) => row.status),
    ['placed', 'processing', 'shipped', 'delivered'],
  );
});

const shipping = {
  recipient: 'Alex Rowan', street: '14 Demo Lane', city: 'Ostrava', postalCode: '700 30', payment: 'approve',
};

test('customer cart and mock checkout persist an owned order and clear the cart', async (t) => {
  const shop = await fixture(t);
  const customer = shop.browser();
  const peer = shop.browser();
  await customer.login('alex');
  await peer.login('jamie');

  assert.match((await customer.get('/cart')).body, /Your cart is empty/);
  assertRedirect(await customer.get('/checkout'), '/cart');
  assertRedirect(await customer.post('/cart/items', { productId: 1, quantity: 1 }), '/cart');
  assert.match((await customer.get('/cart')).body, /Kite Dripper/);
  assert.match((await peer.get('/cart')).body, /Your cart is empty/);
  assertRedirect(await customer.post('/cart/items/1/update', { quantity: 2 }), '/cart');
  assert.match((await customer.get('/cart')).body, /€68\.00/);
  assert.equal((await customer.post('/cart/items/1/update', { quantity: 0 })).status, 422);
  assert.equal((await customer.post('/cart/items', { productId: 7, quantity: 1 })).status, 409);
  assertRedirect(await customer.post('/cart/items', { productId: 5, quantity: 1 }), '/cart');
  assertRedirect(await customer.post('/cart/items/5/remove'), '/cart');
  assert.doesNotMatch((await customer.get('/cart')).body, /Paper Filters/);

  const checkout = await customer.get('/checkout');
  assert.equal(checkout.status, 200);
  assert.match(checkout.body, /value="14 Demo Lane"/);
  assert.match(checkout.body, /Simulated payment/);
  assert.equal((await customer.post('/checkout', { ...shipping, city: '' })).status, 422);

  const declined = await customer.post('/checkout', { ...shipping, payment: 'decline' });
  assert.equal(declined.status, 422);
  assert.match(declined.body, /simulated payment was declined/);
  assert.equal(shop.db.prepare('SELECT count(*) AS count FROM orders').get().count, 4);
  assert.match((await customer.get('/cart')).body, /€68\.00/);

  assertRedirect(await customer.post('/checkout', shipping), '/orders/2105');
  const order = await customer.get('/orders/2105');
  assert.equal(order.status, 200);
  assert.match(order.body, /€68\.00/);
  assert.match(order.body, /badge-placed/);
  assert.match(order.body, /href="\/receipts\/6105"/);
  assert.match((await customer.get('/receipts/6105')).body, /Order SR-2105/);
  assert.match((await customer.get('/cart')).body, /Your cart is empty/);
  assert.equal((await customer.post('/checkout', shipping)).status, 409);
  assert.equal((await peer.get('/orders/2105')).status, 404);
  assert.equal(shop.db.prepare('SELECT stock FROM products WHERE id = 1').get().stock, 12);
  assert.equal(shop.db.prepare('SELECT count(*) AS count FROM orders').get().count, 5);
});

test('checkout rolls back an inventory change when another line is unavailable', async (t) => {
  const shop = await fixture(t);
  const customer = shop.browser();
  await customer.login('alex');
  assertRedirect(await customer.post('/cart/items', { productId: 3, quantity: 2 }), '/cart');
  assertRedirect(await customer.post('/cart/items', { productId: 1, quantity: 1 }), '/cart');
  shop.db.prepare('UPDATE products SET stock = 0 WHERE id = ?').run(1);

  const conflict = await customer.post('/checkout', shipping);
  assert.equal(conflict.status, 409);
  assert.match(conflict.body, /Stock changed/);
  assert.equal(shop.db.prepare('SELECT stock FROM products WHERE id = 3').get().stock, 18);
  assert.equal(shop.db.prepare('SELECT count(*) AS count FROM cart_items WHERE customer_id = 1').get().count, 2);
  assert.equal(shop.db.prepare('SELECT count(*) AS count FROM orders').get().count, 4);
  assert.equal(shop.db.prepare('SELECT count(*) AS count FROM receipts').get().count, 4);
});

test('login rejection, same-origin form policy, and sign-out preserve access boundaries', async (t) => {
  const shop = await fixture(t);
  const customer = shop.browser();
  const failed = await customer.post('/login', { ...DEMO_ACCOUNTS.alex, password: 'incorrect-password' });
  assert.equal(failed.status, 401);
  assert.equal(failed.headers.get('set-cookie'), null);
  assertRedirect(await customer.get('/orders'), '/login');

  const externalOrigin = { Origin: 'http://example.test' };
  assert.equal((await customer.post('/login', DEMO_ACCOUNTS.alex, externalOrigin)).status, 403);
  await customer.login('alex');
  assert.equal((await customer.post('/logout', {}, externalOrigin)).status, 403);
  assert.equal((await customer.get('/orders')).status, 200);

  const signout = await customer.post('/logout', {});
  assertRedirect(signout, '/');
  assert.match(signout.headers.get('set-cookie'), /Max-Age=0/);
  assert.equal(shop.db.prepare('SELECT count(*) AS count FROM sessions').get().count, 0);
  assertRedirect(await customer.get('/orders/2101'), '/login');
  assertRedirect(await customer.get('/receipts/6101'), '/login');
});

test('reset restores seed inventory, order ids, and receipt ownership', async (t) => {
  const shop = await fixture(t);
  const customer = shop.browser();
  await customer.login('alex');
  assertRedirect(await customer.post('/cart/items', { productId: 1, quantity: 1 }), '/cart');
  assertRedirect(await customer.post('/checkout', shipping), '/orders/2105');

  resetDatabase(shop.db);
  assertRedirect(await customer.get('/orders'), '/login');
  await customer.login('alex');
  assert.match((await customer.get('/cart')).body, /Your cart is empty/);
  assert.equal((await customer.get('/orders/2105')).status, 404);
  assert.match((await customer.get('/orders/2101')).body, /badge-processing/);
  assert.equal(shop.db.prepare('SELECT stock FROM products WHERE id = 1').get().stock, 14);
  assert.deepEqual(shop.db.prepare('SELECT id FROM receipts ORDER BY id').all().map((row) => row.id), [6101, 6102, 6103, 6104]);
});

test('only allowlisted assets are served and offline assessment files stay private', async (t) => {
  const shop = await fixture(t);
  const guest = shop.browser();
  const css = await guest.get('/assets/shop.css');
  assert.equal(css.status, 200);
  assert.match(css.headers.get('content-type'), /^text\/css/);
  assert.equal(css.headers.get('x-content-type-options'), 'nosniff');
  for (const path of ['/assessment/EXERCISES.md', '/assessment/REVIEWER-KEY.md', '/src/schema.sql', '/assets/README.md']) {
    assert.equal((await guest.get(path)).status, 404);
  }
});
