"""Serve one synthetic read-only account in the lab network namespace."""
from pathlib import Path
from socket import if_nameindex
import sys
from pyftpdlib import __ver__
from pyftpdlib.authorizers import DummyAuthorizer
from pyftpdlib.handlers import FTPHandler
from pyftpdlib.servers import FTPServer

if {name for _, name in if_nameindex()} != {"lo"}:
    sys.exit("Start this service through infra/lab in its isolated network.")
share = Path(sys.argv[1]).resolve(strict=True)
auth = DummyAuthorizer()
auth.add_user("dispatch", "Stillroom-Demo-Only", str(share), perm="elr")
FTPHandler.authorizer = auth
FTPHandler.banner = f"pyftpdlib {__ver__} ready."
FTPHandler.passive_ports = range(30001, 30004)
FTPServer(("127.0.0.1", 21), FTPHandler).serve_forever()

