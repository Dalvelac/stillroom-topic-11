// Isolated copy of the shop state for repeating the recorded journeys.
import { openDatabase } from '../topic11-stillroom/src/database.mjs';
import { createShopServer } from '../topic11-stillroom/src/http.mjs';
const db=openDatabase(':memory:');
const server=createShopServer(db);
server.once('close',()=>db.close());
server.once('error',error=>{db.close();console.error(error.message);process.exitCode=1;});
for(const signal of ['SIGINT','SIGTERM']) process.once(signal,()=>server.close());
server.listen(18770,'127.0.0.1',()=>console.log('Fresh Stillroom fixture at http://127.0.0.1:18770/'));
